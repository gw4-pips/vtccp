# VCCS Reader / Device Metadata Inventory
Source: DM475V reference manual, DMST 2025 digest, DMCC guide digest, push-script probes  
Date: 2026-05-18

---

## Assessment Legend
- **REPORT** — surface in VCCS verification report
- **CAPTURE** — store in VerificationRecord / database, not shown on report
- **SKIP** — not useful for VCCS purposes

---

## 1. Capture Parameters

| Field | Push/DMCC Path | Type | Typical Range | Assessment | Notes |
|---|---|---|---|---|---|
| Exposure Time | `r.image.exposureTime` | Number | 15–5000 µs | **CAPTURE** | Useful for audit trail; not ISO-reportable |
| Gain | `r.image.gain` | Number | 1.00–100.00 | **CAPTURE** | Affects image quality; may explain optical grade variance |
| Illumination Intensity | `r.image.illIntensity` | Number | 0–100% | **CAPTURE** | |
| Illumination Enabled | `r.image.illEnabled` | Boolean | true/false | **REPORT** (if false = warning) | Should be flagged if illum off during grading |
| External Illumination Intensity | `r.image.extIllIntensity` | Number | 0–100% | **CAPTURE** | |
| Focus Power | `r.image.focusPower` | Number | −100 to 100 diopters | **CAPTURE** | Variable-focus models only |
| Focus Length | `r.image.focusLength` | Number | 0–1000 mm | **CAPTURE** | |
| Field of View | `r.image.FoV` | Object `{x,y,w,h}` | pixels | **CAPTURE** | Full FoV dimensions |
| Region of Interest | `r.image.RoI` | Object `{x,y,w,h}` | pixels | **CAPTURE** | Active decode region |
| Symbol Quality (decode confidence) | `r.symbology.quality` | Number | 0–100 | **REPORT** | Cognex-proprietary; not ISO. Shows decode confidence |

## 2. Decode / Trigger Parameters

| Field | Push/DMCC Path | Type | Typical Range | Assessment | Notes |
|---|---|---|---|---|---|
| Decode Timeout | `r.timeout` | Number | 100–5000 ms | **CAPTURE** | |
| Trigger Time (ms since boot) | `r.triggerTime` | Number | — | **CAPTURE** | Useful for multi-scan timing |
| Decode Time | `r.decodeTime` | Number | ms | **CAPTURE** | Confirmed present in push (v1.27 DebugRSiblings) |
| Read Setup Index | `r.image.setupIndex` (or `r.readSetup`) | Number | 0–15 | **CAPTURE** | Active decode configuration profile |
| Scan Sequence ID | `r.image.id` | Number | sequential | **CAPTURE** | Per-session scan counter |

## 3. Optical / Calibration Parameters

| Field | Push/DMCC Path | Type | Typical Value | Assessment | Notes |
|---|---|---|---|---|---|
| Calibration Date | `q.calibrationDate` | String | ISO datetime | **REPORT** | Always on report |
| Field Calibrated | `readerProperties.status3D.fieldCalibrated` | Boolean | false (observed) | **REPORT** — WARNING if false | ISO 15426-2 traceability requires field cal |
| Factory Calibrated | `readerProperties.status3D.factoryCalibrated` | Boolean | false (observed) | **REPORT** — WARNING if false | |
| Rmax (Rl) — Light Reflectance | `q.reflectanceLight` | Number | 90–100% | **REPORT** | Exposed in push as part of SCRlRd ("92" in 92/4) |
| Rmin (Rd) — Dark Reflectance | `q.reflectanceDark` | Number | 0–15% | **REPORT** | `MinReflectance` wire in v1.28+ |
| Aperture Reference | Push XML `<ApertureRef>` | String | "17", "07" etc. | **REPORT** | ISO 15415 requires reporting aperture |
| Wavelength | Push XML `<Wavelength>` | Number | 660 (nm) | **REPORT** | ISO formal grade includes wavelength |
| Illumination Angle | Push XML `<Lighting>` | String | "45Q", "30Q", "90" | **REPORT** | ISO formal grade includes angle |
| Grading Standard | Push XML `<GradingStandard>` | String | "ISO 15415:2011" | **REPORT** | |
| Application Standard | Push XML `<ApplicationStandard>` | String | "Custom", "GS1" | **REPORT** | |
| Min Pass Grade | Push XML `<MinPassGrade>` | String | "NA", "B" etc. | **REPORT** (if set) | |

## 4. Device Identity

| Field | DMCC Path | Type | Example | Assessment | Notes |
|---|---|---|---|---|---|
| Device Name | `r.source` (push) | String | "DM475-63530E-PIPS-Verif-Lab" | **REPORT** | User-configured name |
| Model Number | `GET DEVICE.MODEL` | String | "DM475V-LBL-0200" | **REPORT** | Must be fetched via DMCC on connect |
| Serial Number | `GET DEVICE.INFO` | String | "63530E" embedded in name | **REPORT** | |
| Firmware Version | `GET DEVICE.INFO` | String | "6.1.16_sr4" | **REPORT** | Shown in DMST header; important for traceability |
| Hardware Revision | `GET DEVICE.HW-REV` | Number | 1, 2, 3 | **CAPTURE** | |
| IP Address | `GET DEVICE.IP-ADDRESS` | String | "10.10.10.7" | **CAPTURE** | |
| MAC Address | `GET DEVICE.MAC` | String | hex | **CAPTURE** | |

## 5. Optics Source / Compliance Flags (VCCS-specific)

These are computed by VTCCP, not from the device directly:

| VCCS Field | Source | Values | Assessment |
|---|---|---|---|
| `OpticsSource` | Push XML `<OpticsSource>` | "LiveScan", "LoadedImage" | **REPORT** — prominent flag |
| `OpticsCompliant` | Computed: OpticsSource=LiveScan AND FieldCalibrated=true | true/false | **REPORT** — warning if false |
| `CalibrationWarning` | Computed: FieldCalibrated=false OR FactoryCalibrated=false | string | **REPORT** — warning block |

## 6. Interesting Proprietary / Device-Specific Fields (Cognex-only)

These appear in push output and are NOT standard ISO parameters:

| Field | Push XML Tag | Notes |
|---|---|---|
| Symbol Quality | `<SymbolQuality>` | Decode confidence (0–100). Not ISO. Appears in DMST header. |
| Average Grade (ISO row-by-row) | `<AverageGrade>` / `<AGValue>` | The mean of individual ISO-15415 scan grades. "X" for loaded images. |
| Formal Grade string | `<FormalGrade>` | "1/D" = numeric/letter. Full formal = "1/17/660/45Q". |
| Contrast Uniformity (CU) | `<ContrastUniformity>` | Cognex-proprietary CU metric. Not standard ISO parameter but in Webscan lineage. |
| Module Reflectance Distribution | `<MRD>` | Also Cognex-proprietary. Both CU and MRD are in the `q.general` 7-key set. |
| Quiet Zone Grades (per-side) | `<LQZGrade>`, `<BQZGrade>`, `<TQZGrade>`, `<RQZGrade>` | Left/Bottom from rightQuietZone; Top/Right from topQuietZone. Per-quadrant NOT available in push on this firmware. |
| Bar Width Growth (H/V) | `<HorizontalBWG>`, `<VerticalBWG>` | Print growth in %, Webscan lineage. Separate H and V. |
| LLS / BLS Grade | `<LLSGrade>`, `<BLSGrade>` | Left L-Side / Bottom L-Side finder pattern. DataMatrix specific. |

## 7. Fields That Are Empty / Not Yet Wired (Future)

| Field | Status | Expected Source |
|---|---|---|
| DataCodewords | Empty (push) | `q.symbols[0].dataCodewords` — v1.29 probe pending |
| ErrorCorrectionBudget | Empty (push) | `q.symbols[0].ecCodewords` — v1.29 probe pending |
| QR ErrorCorrectionType (L/M/Q/H) | "QR" placeholder | `q.symbols[0].errorCorrectionLevel` — v1.29 probe pending |
| Per-quadrant QZ (ULQZ etc.) | Empty (structural limit) | Not in push on DM475V 6.1.16_sr4 |
| TTR / RTR per-quadrant | Empty (structural limit) | Not in push on this firmware |

---

## Summary: REPORT vs. CAPTURE

### Always REPORT (show on every VCCS report)
Device Name, Firmware Version, Aperture Reference, Wavelength, Lighting Angle,  
Calibration Date, Field Calibrated (+ warning if false), OpticsSource flag,  
OpticsCompliant flag, Grading Standard, Application Standard, Formal Grade,  
Symbol Quality (Cognex decode confidence), Rmax/Rmin (Rl/Rd)

### REPORT with condition
Illumination Enabled (warn if false), MinPassGrade (show if not "NA"),  
DPM mode indicators (if DPM scan), CalibrationWarning block

### CAPTURE (store, don't show by default)
Exposure Time, Gain, FoV/RoI, Focus Power/Length, Decode/Trigger timing,  
Read Setup Index, Scan Sequence ID, IP Address, MAC Address, HW Revision,  
Factory Calibrated (capture but only REPORT the warning)
