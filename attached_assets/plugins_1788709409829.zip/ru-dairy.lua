gs1u = require "aicheckutils"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("Russian Dairy")

function acv_plugin_info(info)
	return {
		name = plugin_name,
		desc = _("Complete Application Identifier evaluation and validation \z
		          according to the GS1 General Specifications.  Additional \z
		          checks validating the Russian Dairy requirements."),
	}
end

-- Override the desc when the spec length requirements are more stringent.
-- Always hide the usual AICheck notes, they don't apply here.
local function rai(t, d)
	return { title = t, desc = d, hide_notes = true }
end

local ai_replace = {
	["01"] = rai("GTIN"),
	["21"] = rai("SN",    N_("Serial Number [n2+an6]")),
	["93"] = rai("KEY",   N_("Verification Key [n2+an4]")),
}

local function mk_ai(tai, tdesc)
	return { ai = tai, desc = tdesc }
end

-- Define the element string requirements.
-- The second column strings are only used if a required AI is not present.
-- Any AIs not in this list are unwanted, and will also produce an error.
local ai_info = {
	mk_ai("01", N_("GTIN")),
	mk_ai("21", N_("Serial Number [n2+an6]")),
	mk_ai("93", N_("Verification Key [n2+an4]")),
}

local spec = {
	ecc_200_fnc1_1_5 = {  -- GS1 DataMatrix
		mod_size = {
			min = 250,
			-- No maximum specified
		},
		aperture = 200,
	},

	generic = {
		pass_grade = 1.5,
	},
}

-- Returns aperture in accordance with the GS1 Genereral Specifications
function acv_plugin_recommend(info)
	local di = info.decode_info
	local is_dpm = utils.is_dpm(info)
	return gs1u.get_rec_aperture(spec, di.subsymb, di.module_width, is_dpm)
end

local function check_rd_lengths(plugin_details, aicheck_output)
	for k, v in ipairs(aicheck_output.ais) do
		local req_len = nil

		if v.ai == "21" then
			req_len = 6
		elseif v.ai == "93" then
			req_len = 4
		end

		if req_len and (#v.data ~= req_len) then
			plugin_details[k].errors = plugin_details[k].errors or {}
			table.insert(plugin_details[k].errors,
			             string.format(_("Must be %s characters"), req_len))
			plugin_details[k].status = gs1u.plugin_status.fail
		end
	end
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local pl = info.code.param_list
	local xdim = gs1u.get_min_mod_size(pl)
	local is_dpm = utils.is_dpm(info.code)
	gs1u.set_metric(info.metric)

	local results = { desc = plugin_name }

	if gs1u.results_applicable(spec, di.subsymb, vi.aperture,
	                           xdim, info.always_show, is_dpm) then
		if #di.msg == 0 then
			return utils.get_results_no_msg(results)
		end

		local aicheck_output = gs1u.aicheck(di.msg, di.subsymb)
		results.details = gs1u.get_plugin_details(aicheck_output, ai_replace)
		check_rd_lengths(results.details, aicheck_output)
		-- hr SHOULD NOT be accessed before calling gs1u.get_plugin_details().
		-- The human readable will be updated to use data titles.
		results.output = aicheck_output.human_readable

		gs1u.check_missing(results.details, aicheck_output, ai_info)
		gs1u.check_unwanted(results.details, aicheck_output, ai_info)
		gs1u.check_order(results.details, aicheck_output, ai_info)
		-- Check grade, aperture, mod sizes
		gs1u.do_application_checks(results.details, spec, pl,
		                           di.subsymb, vi.overall_grade, vi.aperture)

		results.pass_grade = gs1u.get_pass_grade(spec, di.subsymb, xdim)
		results.status = gs1u.get_status(results.details)
	else
		if info.always_show and (di.symbology == "dmx") and not is_dpm then
			results.status = gs1u.plugin_status.fail
			results.output = _("Error: Code is missing Function 1")
		else
			utils.set_results_na(results, info.always_show, is_dpm)
		end
	end

	return results
end
