require "gettext-utils"

function acv_plugin_info(info)
	return {
		name = _("Performance Qualification"),
		desc = _("This plugin will select a suitable aperture when \z
		          verifying Data Matrix codes.  Enable when verifying the \z
		          performance qualification test cards."),
	}
end

function acv_plugin_recommend(info)
	if info.decode_info.symbology == "dmx" then
		if info.decode_info.module_width >= 490 then
			return 400
		end

		return 200
	else
		return -1
	end
end
