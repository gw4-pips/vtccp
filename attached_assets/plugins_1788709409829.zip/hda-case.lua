gs1u = require "aicheckutils"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("HDA shipping case")

function acv_plugin_info(info)
	local gs_version = "v26.0"
	local long_desc = string.format(
		_("Checks that the code conforms to the GS1 General Specifications \z
		   (%s) for valid data content, and to the HDA Guidelines for Bar \z
		   Coding (2022)."),
		gs_version
	)

	return { name = plugin_name, desc = long_desc }
end

-- Permitted symbologies: if values are not defined, use generics
local spec = {
	gs1_128 = {
		mod_size = {
			min = 337,
			max = 750,
		},
		aperture = 250,  -- ref 10
	},

	ecc_200_fnc1_1_5 = {  -- GS1 DataMatrix
		mod_size = {
			min =  750,
			max = 1520,
		},
		cutoff = {  -- Do not recommend for mod sizes beyond these limits
			min = 495  -- in microns
		},
		aperture = 500,
	},

	generic = {
		pass_grade = 1.5,  -- grade C
	},
}

function acv_plugin_recommend(info)
	local di = info.decode_info
	local is_dpm = utils.is_dpm(info)
	return gs1u.get_rec_aperture(spec, di.subsymb, di.module_width, is_dpm)
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local pl = info.code.param_list
	local xdim = gs1u.get_min_mod_size(pl)
	local is_dpm = utils.is_dpm(info.code)
	gs1u.set_metric(info.metric)

	local results = { desc = plugin_name }

	if gs1u.results_applicable(spec, di.subsymb, vi.aperture,
	                           xdim, info.always_show, is_dpm) then
		if #di.msg == 0 then
			return utils.get_results_no_msg(results)
		end

		results.details, results.output =
			gs1u.get_aicheck_results(di.msg, di.subsymb, { healthcare = true })

		gs1u.do_application_checks(results.details, spec, pl,
		                           di.subsymb, vi.overall_grade, vi.aperture)

		if results.details[#results.details].title == _("Bar Height") then
			results.details[#results.details].desc = string.format(
				_("Minimum bar height: %s for primary or %s for secondary symbols"),
				utils.dim_str(utils.mk_dim("mm", "double", 12.7, 1)),
				utils.dim_str(utils.mk_dim("mm", "double", 10.1, 1)))
		end

		results.pass_grade = gs1u.get_pass_grade(spec, di.subsymb, xdim)
		results.status = gs1u.get_status(results.details)
	else
		utils.set_results_na(results, info.always_show, is_dpm)
	end

	return results
end
