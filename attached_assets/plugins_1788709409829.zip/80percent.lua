--require "strict"
u = require "utils"
require "gettext-utils"

function acv_plugin_info(info)
	return {
		name = _("80% Aperture"),
		desc = _("This plugin will recommend that an aperture of 80% of the \z
		          module size of a two dimensional code should be used for \z
		          verification."),
	}
end

function acv_plugin_recommend(info)
	local di = info.decode_info

	if u.is_2d_code[di.symbology] then
		return di.module_width * 0.8
	else
		return -1
	end
end
