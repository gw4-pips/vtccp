gs1u = require "aicheckutils"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("GS1 Retail 2D")

function acv_plugin_info(info)
	local gs_version = "v26.0"
	local gs_section = "5.12.3"
	local long_desc = string.format(
		_("Checks that the code conforms to the GS1 General Specifications \z
		   (%s) for 2D codes on trade items scanned in general retail POS \z
		   (%s table 1 addendum 2)."),
		gs_version,
		gs_section
	)

	return { name = plugin_name, desc = long_desc }
end

-- Permitted symbologies: if values are not defined, use generics
local spec = {
	ecc_200_fnc1_1_5 = {},  -- GS1 DataMatrix
	ecc_200          = {},  -- Data Matrix (GS1 Digital Link URI)
	["2005"]         = {},  -- QR (GS1 Digital Link URI)

	generic = {
		mod_size = {
			min = 396,  -- in microns
			max = 990,  -- in microns
		},
		cutoff = {  -- Do not recommend for mod sizes beyond these limits
			min = 365  -- in microns
		},
		pass_grade = 1.5,  -- grade C
		aperture = 300,    -- ref 12
	},
}

-- Returns aperture in accordance with the GS1 Genereral Specifications
function acv_plugin_recommend(info)
	local di = info.decode_info
	local is_dpm = utils.is_dpm(info)
	return gs1u.get_rec_aperture(spec, di.subsymb, di.module_width, is_dpm)
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local pl = info.code.param_list
	local xdim = gs1u.get_min_mod_size(pl)
	local is_dpm = utils.is_dpm(info.code)
	gs1u.set_metric(info.metric)

	local results = { desc = plugin_name }

	if gs1u.results_applicable(spec, di.subsymb, vi.aperture,
	                           xdim, info.always_show, is_dpm) then
		if #di.msg == 0 then
			return utils.get_results_no_msg(results)
		end

		results.details, results.output = gs1u.get_aicheck_results(di.msg, di.subsymb)
--		local num_ais = #results.details

		gs1u.do_application_checks(results.details, spec, pl,
		                           di.subsymb, vi.overall_grade, vi.aperture)

		results.pass_grade = gs1u.get_pass_grade(spec, di.subsymb, xdim)
		results.status = gs1u.get_status(results.details)
--[[
		-- GS1 Digital Link data content is not yet checked, so make it clear
		-- that only the overall grade, aperture & module size are validated.
		if num_ais == 0 then
			local skey = results.status
			for k, v in pairs(utils.plugin_status) do
				if v == results.status then
					skey = k
					break
				end
			end

			results.output = string.format(
				_("Symbol quality: %s - data content not checked"),
				_(utils.plugin_status_str[skey]))
		end
--]]
	else
		utils.set_results_na(results, info.always_show, is_dpm)
	end

	return results
end
