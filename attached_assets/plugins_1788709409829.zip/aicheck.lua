aicu = require "aicheckutils"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("GS1 Data Content")

function acv_plugin_info(info)
	return {
		name = plugin_name,
		desc = _("This plugin checks that the application identifiers used in \z
		          a code conforms to the GS1 General Specifications.  The \z
		          human readable representation is provided as the output."),
	}
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local results = { desc = plugin_name }

	if aicu.ai_checked_with_fnc1[di.subsymb] then
		if #di.msg == 0 then
			return utils.get_results_no_msg(results)
		end

		local aicheck_output = aicu.aicheck(di.msg, di.subsymb)
		results.details = aicu.get_plugin_details(aicheck_output)
		results.output = aicheck_output.human_readable
		results.status = aicu.get_status(results.details)

	elseif info.always_show then
		results.status = aicu.plugin_status.fail
		results.output = _("Error: Code is missing Function 1")
	else
		results = { status = aicu.plugin_status.na }
	end

	return results
end
