local utils = require "utils"
require "gettext-utils"

local plugin_name = _("Latin-1 message")

function acv_plugin_info(info)
	return {
		name = plugin_name,
		desc = _("Display the code message in ISO/IEC 8859-1 \z
		          (Latin alphabet no. 1), if valid."),
	}
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local converted

	-- C1 controls are permitted in 8859-1, so all 8-bit values are supported.
	-- Even so, we do expect to find at least one supplement character.
	if (#di.msg > 0) and (info.always_show or di.msg:match("[\160-\255]")) then
		-- 8859-1 is just U+0000 to U+00FF, no lookup necessary
		converted = utf8.char(di.msg:byte(1, -1))
	end

	local results = { desc = plugin_name }

	if not converted then
		if info.always_show then
			return utils.get_results_no_msg(results)
		end

		return { status = utils.plugin_status.na }
	end

	results.status = utils.plugin_status.pass
	results.output = utils.parse_msg(converted, {
		fnc = true, ctrl = true, whitespace = false, hibit = false
	})
	return results
end

