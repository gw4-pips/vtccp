--require "strict"
--dbg = require "dbg"

aicu = require "aicheckutils"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("Brazil Healthcare")

function acv_plugin_info(info)
	return {
		name = plugin_name,
		desc = _("Complete Application Identifier evaluation and validation \z
		          according to the GS1 General Specifications.  Additional \z
		          checks validating the requirements of resolution RDC \z
		          157/2017 from the Brazilian Ministry of Health."),
	}
end

local function mk_ai(tai, tdesc)
	return { ai = tai, desc = tdesc, }
end

local ai_info = {
	mk_ai("01",  N_("GTIN")),
	mk_ai("713", N_("ANVISA Registry Number")),
	mk_ai("21",  N_("Serial Number")),
	mk_ai("17",  N_("Expiration Date")),
	mk_ai("10",  N_("Batch Number")),
}

local spec = {
	ecc_200_fnc1_1_5 = {  -- GS1 DataMatrix
		mod_size = {
			min = 396,
			max = 990,
		},
		aperture = 200,
	},

	generic = {
		pass_grade = 1.5,
	},
}

-- Returns aperture in accordance with the GS1 Genereral Specifications
function acv_plugin_recommend(info)
	local di = info.decode_info
	local is_dpm = utils.is_dpm(info)
	return aicu.get_rec_aperture(spec, di.subsymb, di.module_width, is_dpm)
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local pl = info.code.param_list
	local xdim = aicu.get_min_mod_size(pl)
	local is_dpm = utils.is_dpm(info.code)
	aicu.set_metric(info.metric)

	local results = { desc = plugin_name }

	if aicu.results_applicable(spec, di.subsymb, vi.aperture,
	                           xdim, info.always_show, is_dpm) then
		if #di.msg == 0 then
			return utils.get_results_no_msg(results)
		end

		local aicheck_output = aicu.aicheck(di.msg, di.subsymb,
		                                    { healthcare = true })
		results.details = aicu.get_plugin_details(aicheck_output)
		results.output = aicheck_output.human_readable

		aicu.check_missing(results.details, aicheck_output, ai_info)
		aicu.check_order(results.details, aicheck_output, ai_info)
		-- Check grade, aperture, mod sizes
		aicu.do_application_checks(results.details, spec, pl,
		                           di.subsymb, vi.overall_grade, vi.aperture)

		results.pass_grade = aicu.get_pass_grade(spec, di.subsymb, xdim)
		results.status = aicu.get_status(results.details)
	else
		utils.set_results_na(results, info.always_show, is_dpm)
	end

	return results
end
