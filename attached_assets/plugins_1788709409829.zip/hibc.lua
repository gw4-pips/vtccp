-- require "strict"

require "gettext-utils"
utils = require "utils"
hu = require "hibcutils"

local plugin_name = _("HIBC")

function acv_plugin_info(info)
	return {
		name = plugin_name,
		desc = _("Health Industry Bar Code validation, according to the \z
		          Supplier Labeling Standard v2.6 (2016)."),
		default_on = true,
	}
end

local spec = {
	mod_size = {
		["1D"] = { min = 165 },
		["2D"] = { min = 250 },
	},
	wnr = {
		str = "3:1",                  -- Displayed target ratio
		min = 2.85,                   -- Inclusive, (< 2.85 will fail)
		max = 3.15,                   -- Exclusive, (>= 3.15 will fail)
		target_min = 2.95,            -- Inclusive, (< 2.95 will warn)
		target_max = 3.05,            -- Exclusive, (>= 3.05 will warn)
	},
	bar_height = {
		min = 15,                     -- Ratio to symbol width (inc. margins) >= 14.5%
		err = hu.plugin_status.fail,  -- What is the result if less than min?
	},
	pass_grade   = 1.5,  -- Grade C, fail if lower
	target_grade = 2.5,  -- Grade B, warn if lower
	aperture = 150,      -- 06 ref num, only for linears
}

-- Store the parent symbology as value for err msg that lists valid symbs
local check_symb = {
	code39   = "linear",
	code128  = "linear",
	["2005"] = "qr",
	ecc_200  = "dmx",
}

local gs1_symb = {
	gs1_128          = true,
	["2005_fnc1_1"]  = true,
	ecc_200_fnc1_1_5 = true,
}

function acv_plugin_recommend(info)
	local di = info.decode_info

	if (check_symb[di.subsymb] == "linear") and (di.msg:sub(1, 1) == '+') then
		return spec.aperture
	end

	return -1
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local is_dpm = utils.is_dpm(info.code)
	hu.set_metric(info.metric)

	local results = { desc = plugin_name }

	if not check_symb[di.subsymb] or is_dpm then
		if not info.always_show then
			return { status = hu.plugin_status.na }
		end

		if is_dpm then
			utils.set_results_na(results, info.always_show, is_dpm)
		elseif gs1_symb[di.subsymb] then
			results.output = string.format(_("Error! GS1 symbology variants not valid for %s"),
			                               plugin_name)
		else
			results.output = _("Error! Unexpected symbology, this plugin can only check:") ..
			                 utils.get_fullsymb_list(check_symb)
		end

		results.status = hu.plugin_status.fail

		return results
	-- Only continue if (correct symb && (first char == '+' || always_show))
	elseif (di.msg:sub(1, 1) ~= '+') and not info.always_show then
		return { status = hu.plugin_status.na }
	end

	local pl = info.code.param_list

	results.pass_grade = spec.pass_grade
	results.details, results.output = hu.get_core_results(di.msg, di.subsymb,
	                                                      di.decode_time)
	hu.check_grade(results.details, vi.overall_grade,
	               spec.pass_grade, spec.target_grade)

	if check_symb[di.subsymb] == "linear" then
		utils.check_aperture(results.details, vi.aperture, spec.aperture)
		hu.check_mod_size(results.details, pl, spec.mod_size["1D"])
		hu.check_min_height(results.details, pl, spec.bar_height)

		if di.subsymb == "code39" then
			hu.check_wn_ratio(results.details, pl, spec.wnr)
			-- check inter-character gap == xdim
		end
	else
		hu.check_mod_size(results.details, pl, spec.mod_size["2D"])
	--	hu.check_2d_symb(results.details, di.symbology, di.subsymb)

		if di.subsymb:sub(1, 4) == "2005" then
			utils.check_qr_qz(results.details, pl)
		end
	end

	results.status = hu.get_status(results.details)

	return results
end
