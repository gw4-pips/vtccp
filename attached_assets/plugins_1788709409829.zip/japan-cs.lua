require "gettext-utils"

function acv_plugin_info(info)
	return {
		name = _("Japanese convenience store"),
		desc = _("This plugin will select a suitable aperture when verifying \z
		          GS1-128 symbols."),
	}
end

function acv_plugin_recommend(info)
	local di = info.decode_info
	local ri = info.reader_info

	if di.subsymb == "gs1_128" then
		if (di.module_width < 180 and ri.base_aperture <= 75) then
			return 75  -- ref 03
		end

		return 125  -- ref 05
	end

	return -1
end
