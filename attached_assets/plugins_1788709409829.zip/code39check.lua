--require "strict"
--dbg = require "dbg"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("Code 39 Check Character")

local check_symb = {
	code39     = true,
	code39_tri = true,
}

function acv_plugin_info(info)
	return {
		name = plugin_name,
		desc = _("Validate the modulus 43 check character for Code 39 codes."),
		default_on = true,
	}
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local results = { status = utils.plugin_status.fail, desc = plugin_name }

	if not check_symb[di.subsymb] then
		if info.always_show then
			results.output = _("Error! Unexpected symbology, this plugin can only check:") ..
			                 utils.get_fullsymb_list(check_symb, "linear")
		else
			results = { status = utils.plugin_status.na }
		end

		return results
	end

	if #di.msg == 0 then
		return utils.get_results_no_msg(results)
	elseif (di.msg:sub(1, 1) == '-') and not info.always_show then
		return { status = utils.plugin_status.na }
	end

	local cdx, cdr = utils.mod43_check(di.msg)

	if not cdx then
		results.output = _("Error: cannot calculate checksum")
	elseif cdx == cdr then
		results.status = utils.plugin_status.pass
		results.output = _("Check digit OK")
	else
		results.output = string.format(_("Expected: %s (Read: %s)"),
		                               "'" .. cdx .. "'",
		                               "'" .. utils.parse_msg(cdr, {}) .. "'")
	end

	return results
end
