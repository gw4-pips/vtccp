gs1u = require "aicheckutils"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("GS1 Retail & Distribution")

function acv_plugin_info(info)
	local gs_version = "v26.0"
	local gs_section = "5.12.3"
	local long_desc = string.format(
		_("Checks that the code conforms to the GS1 General Specifications \z
		   (%s) for trade items scanned at general retail POS and general \z
		   distribution (%s table 3).  The human readable representation is \z
		   provided as the output."),
		gs_version,
		gs_section
	)

	local long_name = _("GS1 Retail and Distribution")
	return { name = long_name, desc = long_desc }
end

-- Permitted symbologies: if values are not defined, use generics
local spec = {
	ean8    = {},
	ean13   = {},
	upce    = {},
	upca    = {},

	databar = {
		height = {
			scalar = 46  -- Min height = 46 * X-dimension
		},
	},

	databar_expanded = {},

	generic = {
		mod_size = {
			min = 495,  -- in microns
			max = 660,  -- in microns
		},
		pass_grade = 1.5,  -- grade C
		aperture = 150,    --ref 06
	},
}

-- Returns aperture in accordance with the GS1 Genereral Specifications
function acv_plugin_recommend(info)
	local di = info.decode_info
	local is_dpm = utils.is_dpm(info)
	return gs1u.get_rec_aperture(spec, di.subsymb, di.module_width, is_dpm)
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local pl = info.code.param_list
	local xdim = gs1u.get_min_mod_size(pl)
	local is_dpm = utils.is_dpm(info.code)
	gs1u.set_metric(info.metric)

	local results = { desc = plugin_name }

	if gs1u.results_applicable(spec, di.subsymb, vi.aperture,
	                           xdim, info.always_show, is_dpm) then
		if #di.msg == 0 then
			return utils.get_results_no_msg(results)
		end

		results.details, results.output = gs1u.get_aicheck_results(di.msg, di.subsymb)

		gs1u.do_application_checks(results.details, spec, pl,
		                           di.subsymb, vi.overall_grade, vi.aperture)

		results.pass_grade = gs1u.get_pass_grade(spec, di.subsymb, xdim)
		results.status = gs1u.get_status(results.details)
	else
		utils.set_results_na(results, info.always_show, is_dpm)
	end

	return results
end
