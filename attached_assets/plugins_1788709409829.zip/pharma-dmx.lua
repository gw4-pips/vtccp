gs1u = require "aicheckutils"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("Pharma Pack")

function acv_plugin_info(info)
	return {
		name = plugin_name,
		desc = _("Application Identifier evaluation and validation according to \z
		          the GS1 General Specifications.  This plugin also requires that \z
		          a GS1 DataMatrix symbol is used, which contains a GTIN (01), \z
		          batch/lot number (10) and an expiration date (17).\n\nElement \z
		          strings are labelled using GS1 data titles.  Valid dates are \z
		          displayed in \"DD/MM/YYYY\" format, or \"MM/YYYY\" if the day \z
		          is not encoded."),
	}
end

local function rai(t)
	return { title = t }
end

local ai_titles = {
	["00"] = rai("SSCC"),
	["01"] = rai("GTIN"),
	["02"] = rai("CONTENT"),
	["10"] = rai("LOT"),
	["11"] = rai("PROD"),
	["12"] = rai("DUE DATE"),
	["13"] = rai("PACK"),
	["15"] = rai("BEST"),
	["16"] = rai("SELL BY"),
	["17"] = rai("EXP"),
	["21"] = rai("SN"),
	["240"] = rai("ADDITIONAL ID"),
	["250"] = rai("SECONDARY SERIAL"),
	["30"] = rai("VAR. COUNT"),
	["37"] = rai("COUNT"),
	["710"] = rai("NHRN PZN"),  -- Germany
	["711"] = rai("NHRN CIP"),  -- France
	["712"] = rai("NHRN CN"),   -- Spain
	["713"] = rai("NHRN DRN"),  -- Brazil "ANVISA"
	["714"] = rai("NHRN AIM"),  -- Portugal
	["90"] = rai("INTERNAL"),
	["91"] = rai("INTERNAL"),
	["92"] = rai("INTERNAL"),
	["93"] = rai("INTERNAL"),
	["94"] = rai("INTERNAL"),
	["95"] = rai("INTERNAL"),
	["96"] = rai("INTERNAL"),
	["97"] = rai("INTERNAL"),
	["98"] = rai("INTERNAL"),
	["99"] = rai("INTERNAL"),
}

local fixed_fmt_date_ais = {
	["11"] = true,
	["12"] = true,
	["13"] = true,
	["15"] = true,
	["16"] = true,
	["17"] = true,
}

local function gs1_enc_to_fixed_date_str(data)
	local enc_YY, enc_MM, enc_DD = data:match("(%d%d)(%d%d)(%d%d)")

	local cur_yyyy = os.date("%Y")
	local cur_cent = math.modf(cur_yyyy / 100)
	local diff = (cur_yyyy % 100) - enc_YY
	local cent_offset = 0

	if diff < -50 then
		cent_offset = -1
	elseif diff >= 50 then
		cent_offset = 1
	end

	local enc_YYYY = ((cur_cent + cent_offset) * 100) + enc_YY

	if enc_DD == "00" then
		return string.format("%02d/%04d", enc_MM, enc_YYYY)
	end

	return string.format("%02d/%02d/%04d", enc_DD, enc_MM, enc_YYYY)
end

local function fixed_date_func(ai, data, orig_str)
	if not fixed_fmt_date_ais[ai] then
		return orig_str
	end

	return gs1_enc_to_fixed_date_str(data)
end

local function mk_ai(tai, tdesc)
	return { ai = tai, desc = tdesc }
end

local ai_info = {
	mk_ai("01", N_("GTIN")),
	mk_ai("10", N_("Batch Number")),
	mk_ai("17", N_("Expiration Date")),
}

local spec = {
	ecc_200_fnc1_1_5 = {  -- GS1 DataMatrix
		-- No module size requirements
		pass_grade = 1.5,  -- grade C
		aperture = 200,    -- ref 08
	},
}

-- Returns aperture in accordance with the GS1 Genereral Specifications
function acv_plugin_recommend(info)
	local di = info.decode_info
	local is_dpm = utils.is_dpm(info)
	local symb_spec = spec[di.subsymb]
	if symb_spec and symb_spec.aperture and not is_dpm then
		return symb_spec.aperture
	end

	return -1
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local is_dpm = utils.is_dpm(info.code)
	local results = { desc = plugin_name }
	local symb_spec = spec[di.subsymb]

	if symb_spec and not is_dpm then
		if #di.msg == 0 then
			return utils.get_results_no_msg(results)
		end

		local aicheck_output = gs1u.aicheck(di.msg, di.subsymb, { healthcare = true })
		results.details = gs1u.get_plugin_details(aicheck_output, ai_titles, fixed_date_func)
		-- hr SHOULD NOT be accessed before calling gs1u.get_plugin_details().
		-- The human readable will be updated to use data titles.
		results.output = aicheck_output.human_readable

		gs1u.check_missing(results.details, aicheck_output, ai_info)

		gs1u.check_grade(results.details, vi.overall_grade, symb_spec.pass_grade)
		gs1u.check_aperture(results.details, vi.aperture, symb_spec.aperture)

		results.pass_grade = symb_spec.pass_grade
		results.status = gs1u.get_status(results.details)
	else
		if info.always_show and (di.symbology == "dmx") and not is_dpm then
			results.status = gs1u.plugin_status.fail
			results.output = _("Error: Code is missing Function 1")
		else
			utils.set_results_na(results, info.always_show, is_dpm)
		end
	end

	return results
end
