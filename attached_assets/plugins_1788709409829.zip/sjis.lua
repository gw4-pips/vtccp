local utils = require "utils"
--local utf8_validator = require 'utf8_validator'
require "gettext-utils"

local plugin_name = _("Shift JIS Message")

function acv_plugin_info(info)
	return {
		name = plugin_name,
		desc = _("Display the code message in Shift JIS (Japanese), if valid."),
	}
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	di.msg = di.msg or ""
	local sjis = (info.always_show or not utf8.len(di.msg)) and
	             acv_strconv(di.msg, "CP932")  -- AKA "SJIS-WIN"
	local results = { desc = plugin_name }

	if info.always_show then
		if (#di.msg < 1) or (not sjis) then
			results.status = utils.plugin_status.fail
			results.output = _("Error: Invalid Shift JIS")
			return results
		end
	elseif utils.is_ascii(di.msg) or (not sjis) then
		return { status = utils.plugin_status.na }
	end

	results.status = utils.plugin_status.pass
	results.output = utils.parse_msg(sjis, { fnc = true, ctrl = true,
	                                         whitespace = false, hibit = false })
	return results
end

