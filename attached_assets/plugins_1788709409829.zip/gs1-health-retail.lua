gs1u = require "aicheckutils"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("GS1 Healthcare Retail")

function acv_plugin_info(info)
	local gs_version = "v26.0"
	local gs_section = "5.12.3"
	local long_desc = string.format(
		_("Checks that the code conforms to the GS1 General Specifications \z
		   (%s) for regulated healthcare retail consumer trade items not \z
		   scanned in general distribution (%s table 10).  The human readable \z
		   representation is provided as the output."),
		gs_version,
		gs_section
	)

	return { name = plugin_name, desc = long_desc, default_on = true }
end

local on_demand_fmt = N_("The allowance for X-dimensions between %s and %s is \z
                          only applicable to on demand print processes. For \z
                          all other printing processes, an X-dimension of %s \z
                          is the minimum allowable size.")

-- Permitted symbologies: if values are not defined, use generics
local spec = {
	ean8    = {},
	ean13   = {},
	upce    = {},
	upca    = {},
	databar = {},
	databar_expanded = {},
	databar_limited  = {},
	cca = {},
	ccb = {},
	ccc = {},

	itf14 = {
		height = {
			absolute = 12.70
		},
	},

	gs1_128 = {
		height = {
			absolute = 12.70
		},
	},

	ecc_200_fnc1_1_5 = {  -- GS1 DataMatrix
		mod_size = {
			min = 375,
			max = 990,
			note_fmt = on_demand_fmt,
			note_args = { 375, 396, 396 },
		},
		cutoff = {  -- Do not recommend for mod sizes beyond these limits
			max = 990  -- in microns
		},
		aperture = 200,
	},

	generic = {
		mod_size = {
			min = 249,  -- in microns
			max = 660,  -- in microns
			note_fmt = on_demand_fmt,
			note_args = { 249, 264, 264 },
		},
		cutoff = {  -- Do not recommend for mod sizes beyond these limits
			max = 660  -- in microns
		},
		pass_grade = 1.5,  -- grade C
		aperture = 150,    -- ref 06
	},
}

-- Returns aperture in accordance with the GS1 Genereral Specifications
function acv_plugin_recommend(info)
	local di = info.decode_info
	local is_dpm = utils.is_dpm(info)
	return gs1u.get_rec_aperture(spec, di.subsymb, di.module_width, is_dpm)
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local pl = info.code.param_list
	local xdim = gs1u.get_min_mod_size(pl)
	local is_dpm = utils.is_dpm(info.code)
	gs1u.set_metric(info.metric)

	local results = { desc = plugin_name }

	if gs1u.results_applicable(spec, di.subsymb, vi.aperture,
	                           xdim, info.always_show, is_dpm) then
		if #di.msg == 0 then
			return utils.get_results_no_msg(results)
		end

		results.details, results.output =
			gs1u.get_aicheck_results(di.msg, di.subsymb, { healthcare = true })

		gs1u.do_application_checks(results.details, spec, pl,
		                           di.subsymb, vi.overall_grade, vi.aperture)

		results.pass_grade = gs1u.get_pass_grade(spec, di.subsymb, xdim)
		results.status = gs1u.get_status(results.details)
	else
		utils.set_results_na(results, info.always_show, is_dpm)
	end

	return results
end
