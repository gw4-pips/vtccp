utils = require "utils"
require "gettext-utils"

local plugin_name = _("GS1 UPC")

local check_symb = {
	upce   = true,
	upce_2 = true,
	upce_5 = true,
	upca   = true,
	upca_2 = true,
	upca_5 = true,
}

function acv_plugin_info(info)
	return {
		name = _("GS1 UPC Human Readable"),
		desc = _("Show the UPC number in the form that appears under the barcode."),
		default_on = true,
	}
end

local function zero_suppress_upce(msg)
	if not msg or #msg ~= 12 or msg:sub(1, 1) ~= '0' then
		return msg
	end

	local r = ""

	if msg:sub(5, 8) == "0000" then
		local d4 = msg:sub(4, 4)

		if d4:find("[012]") then
			r = msg:sub(9, 11) .. d4
		elseif msg:sub(9, 9) == '0' then
			r = d4 .. msg:sub(10, 11) .. '3'
		end
	elseif msg:sub(7, 10) == "0000" then
		local d11 = msg:sub(11, 11)

		if msg:sub(6, 6) == '0' then
			r = msg:sub(4, 5) .. d11 .. '4'
		else
			r = msg:sub(4, 6) .. d11
		end
	end

	if #r == 0 then
		return msg
	end

	return msg:sub(1, 3) .. r .. msg:sub(12, 12)
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local results = { status = utils.plugin_status.fail, desc = plugin_name }

	if not check_symb[di.subsymb] then
		if info.always_show then
			results.output = _("Error! Unexpected symbology, this plugin can only check:") ..
			                 utils.get_fullsymb_list(check_symb, "linear")
		else
			results = { status = utils.plugin_status.na }
		end

		return results
	end

	if #di.msg == 0 then
		return utils.get_results_no_msg(results)
	end

	if di.msg:sub(1, 13):find("^0%d+$") then
		if di.subsymb:sub(1, 4) == "upca" then
			results.output = di.msg:sub(2)
		else
			results.output = zero_suppress_upce(di.msg:sub(2, 13)) .. di.msg:sub(14)
		end
	end

	if results.output and (#results.output < #di.msg) then
		results.output = utils.parse_msg(results.output, {})
		results.status = utils.plugin_status.pass
	else
		results.output = _("Error: Invalid UPC")
	end

	return results
end
