gs1u = require "aicheckutils"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("GS1 Distribution")

function acv_plugin_info(info)
	local gs_version = "v26.0"
	local gs_section = "5.12.3"
	local long_desc = string.format(
		_("Checks that the code conforms to the GS1 General Specifications \z
		   (%s) for trade items scanned in general distribution only \z
		   (%s table 2).  The human readable representation is provided as \z
		   the output."),
		gs_version,
		gs_section
	)

	return { name = plugin_name, desc = long_desc, default_on = true }
end

local spec = {
	ean13 = {},
	upce  = {},
	upca  = {},
	databar = {},
	databar_expanded = {},
	databar_limited  = {},

	-- Gen Spec 5.12.3.2 notes technically allow for X-dim down to 250µm if:
	--     "there is absolutely no possibility of printing the full size
	--      barcode because the trade item is physically too small".
	-- We haven't yet seen a legitimate example of this edge case so will
	-- fail codes with X-Dim less than 495µm (for ITF-14 and GS1-128).
	gs1_128 = {
		mod_size = {
			min =  495,  -- Change to 250 if scanning tiny trade items
			max = 1016,
		},
		cutoff = {
			min = 330  -- Recommend & check for codes down to 330 µm
		},
	},

	itf14 = {
		mod_size = {
			min =  495,  -- Change to 250 if scanning tiny trade items
			max = 1016,
		},
		cutoff = {
			min = 330  -- Recommend & check for codes down to 330 µm
		},
		big_spec = {
			threshold = 634.5,  -- Xdim in microns when alt. spec is used
			pass_grade = 0.5,   -- grade D
			aperture = 500,     -- ref: 20
		},
	},

	generic = {
		mod_size = {
			min = 495,  -- Except for itf14 & gs1_128
			max = 660,  -- Except for itf14 & gs1_128
		},
		cutoff = {  -- Do not recommend for mod sizes beyond these limits
			min = 495  -- in microns
		},

		pass_grade = 1.5,  -- grade C
		aperture   = 250,  -- ref: 10
	},
}

-- Returns aperture in accordance with the GS1 Genereral Specifications
function acv_plugin_recommend(info)
	local di = info.decode_info
	local is_dpm = utils.is_dpm(info)
	return gs1u.get_rec_aperture(spec, di.subsymb, di.module_width, is_dpm)
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local pl = info.code.param_list
	local xdim = gs1u.get_min_mod_size(pl)
	local is_dpm = utils.is_dpm(info.code)
	gs1u.set_metric(info.metric)

	local results = { desc = plugin_name }

	if gs1u.results_applicable(spec, di.subsymb, vi.aperture,
	                           xdim, info.always_show, is_dpm) then
		if #di.msg == 0 then
			return utils.get_results_no_msg(results)
		end

		results.details, results.output = gs1u.get_aicheck_results(di.msg, di.subsymb)

		gs1u.do_application_checks(results.details, spec, pl,
		                           di.subsymb, vi.overall_grade, vi.aperture)

		results.pass_grade = gs1u.get_pass_grade(spec, di.subsymb, xdim)
		results.status = gs1u.get_status(results.details)
	else
		utils.set_results_na(results, info.always_show, is_dpm)
	end

	return results
end
