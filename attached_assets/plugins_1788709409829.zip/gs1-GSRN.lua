gs1u = require "aicheckutils"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("GS1 GSRNs")

function acv_plugin_info(info)
	local gs_version = "v26.0"
	local gs_section = "5.12.3"
	local long_desc = string.format(
		_("Checks that the code conforms to the GS1 General Specifications \z
		   (%s) for codes containing GSRN keys (%s table 11).  The human \z
		   readable representation is provided as the output."),
		gs_version,
		gs_section
	)

	local long_name = _("GS1 Global Service Relation Numbers")
	return { name = long_name, desc = long_desc, default_on = true }
end

-- Permitted symbologies: if values are not defined, use generics
local spec = {
	gs1_128 = {
		mod_size = {
			min = 170,
			max = 495,
		},
		height = {
			absolute = 12.70
		},
		aperture = 125,  -- ref 05
	},

	-- Technically you are only allowed to use the 249-264 µm lower xdim range
	-- for on-demand printing.  In reality, all GSRNs are created "on-demand".
	databar_expanded = {
		mod_size = {
			min = 249,
			max = 660,
		},
		aperture = 150,  -- ref 06
	},

	ecc_200_fnc1_1_5 = {},  -- GS1 DataMatrix
	["2005_fnc1_1"]  = {},  -- GS1 QR

	generic = {
		mod_size = {
			min = 254,  -- in microns
			max = 495,  -- in microns
		},
		pass_grade = 1.5,  -- grade C
		aperture = 200,    -- ref 08
	},
}

local function mk_req_ai_list(ai_tab)
	local ret = {}

	for k, v in ipairs(ai_tab) do
		ret[v] = true
	end

	return ret
end

local req_ais = { "8017", "8018", "8019" }
req_ais = mk_req_ai_list(req_ais)

-- Returns aperture in accordance with the GS1 Genereral Specifications
function acv_plugin_recommend(info)
	local di = info.decode_info
	local is_dpm = utils.is_dpm(info)
	local aperture = gs1u.get_rec_aperture(spec, di.subsymb, di.module_width, is_dpm)

	-- Only recommend aperture if msg contains at least one of the required AIs
	if (aperture > 0) and gs1u.msg_contains_req_ai(req_ais, di.msg, di.subsymb) then
		return aperture
	end

	return -1
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local pl = info.code.param_list
	local xdim = gs1u.get_min_mod_size(pl)
	local is_dpm = utils.is_dpm(info.code)
	gs1u.set_metric(info.metric)

	local results = { desc = plugin_name }

	if gs1u.results_applicable(spec, di.subsymb, vi.aperture, xdim,
	                           info.always_show, is_dpm, req_ais, di.msg) then
		if #di.msg == 0 then
			return utils.get_results_no_msg(results)
		end

		results.details, results.output = gs1u.get_aicheck_results(di.msg, di.subsymb)
		gs1u.check_contains_req_ai(results.details, req_ais, di.msg, di.subsymb)

		gs1u.do_application_checks(results.details, spec, pl,
		                           di.subsymb, vi.overall_grade, vi.aperture)

		results.pass_grade = gs1u.get_pass_grade(spec, di.subsymb, xdim)
		results.status = gs1u.get_status(results.details)
	else
		utils.set_results_na(results, info.always_show, is_dpm)
	end

	return results
end
