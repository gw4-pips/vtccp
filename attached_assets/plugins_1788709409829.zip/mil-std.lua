require "gettext-utils"
u = require "utils"

local plugin_name = _("MIL-STD-130N")

function acv_plugin_info(info)
	return {
		name = plugin_name,
		desc = _("Validates UII and print quality requirements of Data Matrix \z
		          symbols according to MIL-STD-130N w/Change 1 (2012)."),
	}
end

-- Control characters (decimal values)
local CTRL = {
	EOT = "\4",
	GS = "\29",
	RS = "\30",
}

-- Required message header
local MSG_HEADER = "[)>" .. CTRL.RS
-- Required format and message trailers
local FMT_TRAILER = CTRL.RS
local MSG_TRAILER = CTRL.EOT
-- Combined trailer
local TRAILER = FMT_TRAILER .. MSG_TRAILER

local SPEC = {
	MOD_SIZE = {
		min = 190,  -- 0.0075"
		max = 635,  -- 0.025"
	},
	APERTURE   = 127,  -- 05 ref num
	PASS_GRADE = 3.0,
	PASS_GRADE_DPM = 2.0
}

local function is_code_applicable(subsymb, msg, verify_ap)
	-- If already verified, make sure apertures match
	if (not verify_ap) or (verify_ap == SPEC.APERTURE) then
		-- Check first 4 characters for ISO 15434 message header syntax
		if (subsymb == "ecc_200") and (msg:sub(1, 4) == MSG_HEADER) then
			return true
		end
	end

	return false
end

-- Returns aperture in accordance with MIL-STD-130N (using ISO 15415/16022)
function acv_plugin_recommend(info)
	local di = info.decode_info

	if (not u.is_dpm(info)) and is_code_applicable(di.subsymb, di.msg) then
		return SPEC.APERTURE
	end

	return -1
end

-- Format headers
-- TODO: should we handle deprecated "DD" format for TEIs?
local fheader_type = {
	["05" .. CTRL.GS] = "ai",   -- GS1
	["06" .. CTRL.GS] = "di",   -- ANSI (ASC MH10)
	["12" .. CTRL.GS] = "tei",  -- ATA (CSDD/Spec 2000)
}

-- Format header descriptions
local fheader_desc = {
	ai  = N_("GS1 Application Identifiers"),
	di  = N_("ANSI MH10 Data Identifiers"),
	tei = N_("ATA Text Element Identifiers"),
}

local function get_msg_header_details(msg_head)
	local hd = {
		title  = _("Message Header"),
		value  = u.parse_msg(msg_head),
		desc   = _("Compliance indicator and format trailer"),
		status = u.plugin_status.pass,
	}

	if msg_head ~= MSG_HEADER then
		hd.status = u.plugin_status.fail
		hd.errors = { _("Invalid message header") }
		hd.notes = _("The expected message header format is \"[)>\" followed \z
		              by a record seperator.")
	end

	return hd
end

local function get_fmt_header_details(fh_type, fmt_head)
	local fd = {
		title  = _("Format Header"),
		value  = u.parse_msg(fmt_head),
		desc   = _("Two-digit format indicator and data element separator"),
		status = u.plugin_status.pass,
	}

	if fh_type then
		fd.desc = string.format("%s - %s", fd.desc, _(fheader_desc[fh_type]))
	else
		fd.status = u.plugin_status.fail
		fd.errors = { _("Invalid format header") }
		fd.notes = _("The expected format headers are \"05\", \"06\" or \"12\", \z
		              followed by a group seperator.")
	end

	return fd
end

local function get_extra_fmt_details(extra)
	local ef = {
		title  = _("Extra format"),
		value  = u.parse_msg(extra:sub(1, 7)) .. (#extra > 7 and "…" or ""),
		desc   = _("Format trailer, followed by secondary format (not considered for UII)"),
		status = u.plugin_status.na,
	}

	-- Extra is everything after the first format, so may contain more than one.
	local bad_char = extra:match("[" .. TRAILER .. "]", 2)
	if bad_char then
		ef.status = u.plugin_status.fail
		ef.errors = { string.format("%s: %s", _("Invalid characters"),
		                            u.parse_msg(bad_char)) }
	end

	return ef
end

local function get_trailer_details(trail)
	local tr = {
		title  = _("Trailer"),
		value  = u.parse_msg(trail),
		desc   = _("Format and message trailers"),
		status = u.plugin_status.pass,
	}

	if trail ~= TRAILER then
		tr.status = u.plugin_status.fail
		tr.errors = { _("Invalid trailer") }
		tr.notes = _("The encoded data should be terminated with a record \z
		              seperator, followed by an EOT character")
	end

	return tr
end

local function mk_eid(tmin, tmax, tiac, tdesc)
	return { min = tmin, max = tmax, iac = tiac, desc = tdesc }
end

local function mk_equiv(tmin, tmax, tabv, tdesc)
	return { min = tmin, max = tmax, abv = tabv, desc = tdesc }
end

local function mk_elem(tmin, tmax, tdesc)
	return { min = tmin, max = tmax, desc = tdesc }
end

local AI_IUID_EQUIV = {
	["8002"] = mk_equiv( 1, 20, "CMTI", N_("Cellular mobile telephone identifier")),
	["8003"] = mk_equiv(14, 30, "GRAI", N_("GRAI (GS1 Global Returnable Asset Identifier)")),
	["8004"] = mk_equiv( 4, 30, "GIAI", N_("GIAI (GS1 Global Individual Asset Identifier)")),
}

local function find_ai(raw_str)
	local this_di, data = raw_str:match("^(800[234])(.*)")

	if this_di then
		for id, t in pairs(AI_IUID_EQUIV) do
			if id == this_di then
				return id, data, t
			end
		end
	end

	return nil, raw_str
end

local function check_ai_content(details, raw_str)
	local id, data, info = find_ai(raw_str)
	local enc_err

	local new = {
		title  = id,
		value  = u.parse_msg(data),
		status = u.plugin_status.pass,
		errors = {},
	}

	-- Only allow A-Z, 0-9, specials: [-/]
	local valid_filter = "[%u%d%-%/]"
	local bad_chars, n_ok = data:gsub(valid_filter, '')
	if n_ok < #data then
		table.insert(new.errors, string.format("%s: %s", _("Invalid characters"),
		                                       u.parse_msg(bad_chars)))
		new.status = u.plugin_status.fail
	end

	if not info then
		new.title = _("Extra AI")
		new.desc = _("AI not considered for UII")
		table.insert(details, new)
		return
	else
		new.desc = _(info.desc)
	end

	if #data < info.min then
		table.insert(new.errors, _("Field too short"))
	elseif (info.max > 0) and (#data > info.max) then
		table.insert(new.errors, _("Field too long"))
	end

	if id == "8003" and #data >= info.min then
		local grai = data:sub(1, 14)
		-- First 14 chars must be all digits, starting with 0.
		if grai ~= (grai:match("^0%d+")) then
			table.insert(new.errors, _("Bad data format"))
		else
			local cdx, cdr = u.mod10_check(grai)
			if cdx ~= cdr then
				table.insert(new.errors, _("Wrong check digit"))
			end
		end
	end

	if #new.errors > 0 then
		new.status = u.plugin_status.fail
	end

	table.insert(details, new)
end

local AI_UII_TYPE_DESC = {
	INCOMPLETE = N_("Error: Incomplete UII"),
	IUID_EQUIV = N_("IUID equivalent"),
}

local function check_ai_combo(results)
	for i, v in ipairs(results.details) do
		for id, t in pairs(AI_IUID_EQUIV) do
			if id == v.title then
				v.uii_part = true
				results.output = string.format("%s (%s): %s",
				                               _(AI_UII_TYPE_DESC.IUID_EQUIV),
				                               t.abv, v.value)
				return
			end
		end
	end

	results.output = _(AI_UII_TYPE_DESC.INCOMPLETE)
	results.status = u.plugin_status.fail
end

local DI_UNARY = {
	["18S"] = mk_eid(6, 25, "D", N_("UII (CAGE & serial number within CAGE)")),
	["25S"] = mk_eid(3, 50, "",  N_("Complete UII")),
}

local DI_IUID_EQUIV = {
	["I"]   = mk_equiv(17, 17, "VIN",  N_("VIN (vehicle identification number)")),
	["22S"] = mk_equiv(14, 14, "MEID", N_("MEID (mobile equipment identifier)")),
}

local DI_TERNARY = {
	{
		["7L"]  = mk_eid(6,  6, "LD", N_("DoDAAC (DoD Activity Address Code)")),
		["3V"]  = mk_eid(4, 12, "",   N_("GS1 company prefix")),
		["12V"] = mk_eid(9, 13, "UN", N_("DUNS number")),
		["17V"] = mk_eid(5,  5, "D",  N_("CAGE/NCAGE code")),
		["18V"] = mk_eid(2, 16, "",   N_("IAC & EID (issuing agency & enterprise ID)")),
	},
	{
		["1P"] = mk_elem(1, 32, N_("PIN (part or identifying number)")),
		["1T"] = mk_elem(1, 32, N_("Lot/batch number")),
	},
	{
		["S"] = mk_elem(1, 30, N_("Serial number")),
	},
}

local function find_di(raw_str)
	local this_di, data = raw_str:match("^(%d?%d?%d?%u)(.*)")

	if (not this_di) or (#this_di < 1) then
		return nil, raw_str
	end

	for id, t in pairs(DI_UNARY) do
		if id == this_di then
			return id, data, t
		end
	end

	for id, t in pairs(DI_IUID_EQUIV) do
		if id == this_di then
			return id, data, t
		end
	end

	for i, v in ipairs(DI_TERNARY) do
		for id, t in pairs(v) do
			if id == this_di then
				return id, data, t
			end
		end
	end

	return this_di, data
end

local function check_di_content(details, raw_str)
	local id, data, info = find_di(raw_str)
	local enc_err

	local new = {
		title  = id,
		value  = u.parse_msg(data),
		status = u.plugin_status.pass,
		errors = {},
	}

	-- Only allow A-Z, 0-9, specials: [-/]
	local valid_filter = "[%u%d%-%/]"
	local bad_chars, n_ok = data:gsub(valid_filter, '')
	if n_ok < #data then
		table.insert(new.errors, string.format("%s: %s", _("Invalid characters"),
		                                       u.parse_msg(bad_chars)))
		new.status = u.plugin_status.fail
	end

	if not info then
		if id then
			new.title = string.format("%s: %s", _("Extra DI"), id)
			new.desc = _("DI not considered for UII")
		else
			new.title = _("Unknown DI")
			new.desc = _("Invalid identifier format")
		end

		table.insert(details, new)
		return
	else
		new.desc = _(info.desc)
	end

	if #data < info.min then
		table.insert(new.errors, _("Field too short"))
		new.status = u.plugin_status.fail
	elseif (info.max > 0) and (#data > info.max) then
		table.insert(new.errors, _("Field too long"))
		new.status = u.plugin_status.fail
	end

	table.insert(details, new)
end

local DI_UII_TYPE_DESC = {
	INCOMPLETE = N_("Error: Incomplete UII"),
	IUID_EQUIV = N_("IUID equivalent"),
	COMPLETE   = N_("Complete UII (using Data Identifier)"),
	CONSTRUCT2 = N_("Construct #2 UII (using Data Identifiers)"),
}

local ERR_MAX_LEN = N_("Error: Exceeds maximum length")

local function check_uii_len(results, uii)
	if #uii <= 50 then
		results.status = u.plugin_status.pass
	else
		results.output = string.format("%s - %s", _(ERR_MAX_LEN), results.output)
		results.status = u.plugin_status.fail
	end
end

local function check_di_combo(results)
	for i, v in ipairs(results.details) do
		for id, t in pairs(DI_UNARY) do
			if id == v.title then
				v.uii_part = true
				results.output = string.format("%s: %s%s",
				                               _(DI_UII_TYPE_DESC.COMPLETE),
				                               t.iac, v.value)
				return
			end
		end
	end

	for i, v in ipairs(results.details) do
		for id, t in pairs(DI_IUID_EQUIV) do
			if id == v.title then
				v.uii_part = true
				results.output = string.format("%s (%s): %s",
				                               _(DI_UII_TYPE_DESC.IUID_EQUIV),
				                               t.abv, v.value)
				return
			end
		end
	end

	local found_dis = { false, false, false }
	for i, t in ipairs(DI_TERNARY) do
		for j, d in ipairs(results.details) do
			if found_dis[i] then
				break
			end

			for id, info in pairs(t) do
				if id == d.title then
					found_dis[i] = (info.iac or "") .. d.value
					d.uii_part = true
				end
			end
		end
	end

	local uii = {}
	for i, v in ipairs(found_dis) do
		if not v then
			results.output = _(DI_UII_TYPE_DESC.INCOMPLETE)
			results.status = u.plugin_status.fail
			return
		else
			table.insert(uii, v)
		end
	end

	uii = table.concat(uii)
	results.output = string.format("%s: %s", _(DI_UII_TYPE_DESC.CONSTRUCT2), uii)
	check_uii_len(results, uii)
end

local function mk_cond_elem(tmin, tmax, treq, tdesc)
	local elem = mk_elem(tmin, tmax, tdesc)
	elem.req = {}

	if type(treq) == "table" then
		for i, v in ipairs(treq) do
			elem.req[v] = true
		end
	else
		elem.req[treq] = true
	end

	return elem
end

local TEI_UNARY = {
	UID = mk_eid(3, 50, "",  N_("Complete UII")),
	USN = mk_eid(6, 49, "D", N_("USN (CAGE & serial number within CAGE)")),
	UST = mk_eid(6, 49, "D", N_("UST (CAGE & serial number within CAGE)")),
}

local TEI_EID = {
	MFR = mk_eid(5,  5, "D",  N_("Manufacturer's CAGE/NCAGE code")),
	SPL = mk_eid(5,  5, "D",  N_("Supplier's CAGE/NCAGE code")),
	CAG = mk_eid(5,  5, "D",  N_("CAGE/NCAGE code")),
	DUN = mk_eid(9, 13, "UN", N_("DUNS number")),
	EUC = mk_eid(4, 12, "",   N_("GS1 company prefix")),
}

-- Don't allow MFR-UCN or SPL-SER combinations for construct 1
local TEI_CONSTRUCT1 = {
	SER = mk_cond_elem(1, 30, { "MFR", "CAG", "DUN", "EUC" }, N_("Serial number")),
	UCN = mk_cond_elem(1, 30, { "SPL", "CAG", "DUN", "EUC" }, N_("Unique component ID number")),
}

local TEI_CONSTRUCT2_START = {
	PNO = mk_elem(1, 32, N_("Original part number")),
	LTN = mk_elem(1, 32, N_("Enterprise lot number")),
}

local TEI_CONSTRUCT2_OPT = {
	LOT = mk_cond_elem(1, 32, "PNO", N_("Lot number")),
	BII = mk_cond_elem(1, 32, "LTN", N_("Batch item ID")),
}

local TEI_CONSTRUCT2_END = {
	SEQ = mk_elem(1, 30, N_("Sequential serial number")),
}

local function find_tei(raw_str)
	local this_tei, data = raw_str:match("^(%u?%u?%u?) ?(.*)")

	if (not this_tei) or (#this_tei < 1) then
		return nil, raw_str
	end

	local tlist = {
		TEI_UNARY,
		TEI_EID,
		TEI_CONSTRUCT1,
		TEI_CONSTRUCT2_START,
		TEI_CONSTRUCT2_OPT,
		TEI_CONSTRUCT2_END
	}

	for i, v in ipairs(tlist) do
		for id, t in pairs(v) do
			if id == this_tei then
				return id, data, t
			end
		end
	end

	return this_tei, data
end

local function check_tei_content(details, raw_str)
	local id, data, info = find_tei(raw_str)
	local enc_err

	local new = {
		title  = id,
		value  = u.parse_msg(data),
		status = u.plugin_status.pass,
		errors = {},
	}

	-- Only allow A-Z, 0-9, specials: [-/]
	local valid_filter = "[%u%d%-%/]"
	local bad_chars, n_ok = data:gsub(valid_filter, '')
	if n_ok < #data then
		table.insert(new.errors, string.format("%s: %s", _("Invalid characters"),
		                                       u.parse_msg(bad_chars)))
		new.status = u.plugin_status.fail
	end

	if not info then
		if id then
			new.title = string.format("%s: %s", _("Extra TEI"), id)
			new.desc = _("TEI not considered for UII")
		else
			new.title = _("Unknown TEI")
			new.desc = _("Invalid identifier format")
		end

		table.insert(details, new)
		return
	else
		new.desc = _(info.desc)
	end

	if #data < info.min then
		table.insert(new.errors, _("Field too short"))
		new.status = u.plugin_status.fail
	elseif (info.max > 0) and (#data > info.max) then
		table.insert(new.errors, _("Field too long"))
		new.status = u.plugin_status.fail
	end

	table.insert(details, new)
end

local TEI_UII_TYPE_DESC = {
	INCOMPLETE = N_("Error: Incomplete UII"),
	COMPLETE   = N_("Complete UII (using TEI)"),
	CONSTRUCT1 = N_("Construct #1 UII (using TEIs)"),
	CONSTRUCT2 = N_("Construct #2 UII (using TEIs)"),
}

local function check_tei_combo(results)
	for i, v in ipairs(results.details) do
		for id, t in pairs(TEI_UNARY) do
			if id == v.title then
				v.uii_part = true
				results.output = string.format("%s: %s%s",
				                               _(TEI_UII_TYPE_DESC.COMPLETE),
				                               t.iac, v.value)
				return
			end
		end
	end

	results.output = _(TEI_UII_TYPE_DESC.INCOMPLETE)
	results.status = u.plugin_status.fail

	local eid_tei = false
	local found_teis = {}
	for i, v in ipairs(results.details) do
		if eid_tei then
			break
		end

		for id, info in pairs(TEI_EID) do
			if id == v.title then
				eid_tei = id
				table.insert(found_teis, info.iac .. v.value)
				v.uii_part = true
			end
		end
	end

	if not eid_tei then
		return
	end

	for i, v in ipairs(results.details) do
		for id, info in pairs(TEI_CONSTRUCT1) do
			if (id == v.title) and (info.req[eid_tei]) then
				table.insert(found_teis, v.value)
				v.uii_part = true

				local uii = table.concat(found_teis)
				results.output = string.format("%s: %s",
				                               _(TEI_UII_TYPE_DESC.CONSTRUCT1), uii)
				check_uii_len(results, uii)
				return
			end
		end
	end

	local c2_start, c2_opt = false, false
	for i, v in ipairs(results.details) do
		if c2_start then
			break
		end

		for id, info in pairs(TEI_CONSTRUCT2_START) do
			if id == v.title then
				c2_start = id
				table.insert(found_teis, v.value)
				v.uii_part = true
			end
		end
	end

	if not c2_start then
		return
	end

	for i, v in ipairs(results.details) do
		if c2_opt then
			break
		end

		for id, info in pairs(TEI_CONSTRUCT2_OPT) do
			if (id == v.title) and (info.req[c2_start]) then
				c2_opt = id
				table.insert(found_teis, v.value)
				v.uii_part = true
			end
		end
	end

	for i, v in ipairs(results.details) do
		for id, info in pairs(TEI_CONSTRUCT2_END) do
			if id == v.title then
				table.insert(found_teis, v.value)
				v.uii_part = true

				local uii = table.concat(found_teis)
				results.output = string.format("%s: %s",
				                               _(TEI_UII_TYPE_DESC.CONSTRUCT2), uii)
				check_uii_len(results, uii)
				return
			end
		end
	end

	-- Else leave output as error & status as fail.
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local is_dpm = u.is_dpm(info.code)
	local results = { desc = plugin_name }

	u.set_metric(info.metric)

	-- TODO: should we permit FNC1 in place of GS?  If so, easier to just
	-- replace all instances of FNC1 with GS ahead of checking.
	--local msg = string.gsub(di.msg, "\\1", CTRL.GS)

	-- Only continue if (correct symb && (correct header || always_show))
	if not is_code_applicable(di.subsymb, di.msg, (not is_dpm and vi.aperture)) then
		if (not info.always_show) or (di.subsymb ~= "ecc_200") then
			u.set_results_na(results, info.always_show)
			return results
		end
	end

	local pl = info.code.param_list
	local f_type

	-- Check headers
	do
		-- Check first 4 characters for ISO 15434 message header syntax
		local msg_head = di.msg:sub(1, 4)
		-- Check next 3 characters for ISO 15434 format header syntax
		local fmt_head = di.msg:sub(#msg_head + 1, #msg_head + 3)
		f_type = fheader_type[fmt_head]

		results.details = {
			get_msg_header_details(msg_head),
			get_fmt_header_details(f_type, fmt_head),
		}

		results.status = u.get_status(results.details)
		if results.status == u.plugin_status.fail then
			results.output = _("Error: Invalid message header")
			return results
		end
	end

	local msg, extra, trail, combo_func
	-- Identifiers start from the 8th character
	-- Trim (up to) two control chars from end of message (trailer)
	msg, trail = di.msg:match("^(.-)(%c?%c?)$", 8)

	-- Weird internal-only data
	local text_fmt = CTRL.RS .. "07"
	if msg:match(text_fmt) == text_fmt then
		local rs = CTRL.RS
		msg, extra = msg:match("^([^" .. rs .. "]*)(" .. rs .. ".*)$")
	end

	-- Parse all encoded identifiers
	do
		local elem_func
		if f_type == "ai" then
			elem_func = check_ai_content
			combo_func = check_ai_combo
		elseif f_type == "di" then
			elem_func = check_di_content
			combo_func = check_di_combo
		elseif f_type == "tei" then
			elem_func = check_tei_content
			combo_func = check_tei_combo
		end

		local gs = CTRL.GS
		-- Add a <GS> onto msg so we can use <GS> as the anchor for end of blocks
		-- Parse each <GS> delimited block
		for elem in string.gmatch(msg .. gs, "([^" .. gs .. "]*)" .. gs) do
			-- Function params: details table, raw elem str
			elem_func(results.details, elem)
		end
	end

	-- Check if a valid combination of elements exists to construct the UII.
	-- Also, adds a flag (uii_part) to each detail used in the UII.
	combo_func(results)

	-- Remove any errors from fields not used in UII construct (skip headers).
	for i = 3, #results.details do
		local v = results.details[i]
		if not v.uii_part then
			v.status = u.plugin_status.na
			v.errors = {}
		end
		v.uii_part = nil
	end

	if extra then
		table.insert(results.details, get_extra_fmt_details(extra))
	end

	table.insert(results.details, get_trailer_details(trail))

	results.pass_grade = is_dpm and SPEC.PASS_GRADE_DPM or SPEC.PASS_GRADE
	u.check_grade(results.details, vi.overall_grade, results.pass_grade)
	if not is_dpm then
		u.check_aperture(results.details, vi.aperture, SPEC.APERTURE)
	end
	u.check_mod_size(results.details, pl, SPEC.MOD_SIZE)

	-- If combo_func doesn't find a plausible set of identifiers or if the
	-- combined UII is too long, the overall status will be set to fail.
	-- Otherwise check the individual details including all constituent
	-- identifiers of the UII, as well as the msg trailer & parameter checks.
	if results.status ~= u.plugin_status.fail then
		results.status = u.get_status(results.details)
	end

	-- TODO: check other print quality requirements e.g. SC, MOD & RM >= 2.0

	return results
end

