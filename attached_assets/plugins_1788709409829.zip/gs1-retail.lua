gs1u = require "aicheckutils"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("GS1 Retail")

function acv_plugin_info(info)
	local gs_version = "v26.0"
	local gs_section = "5.12.3"
	local long_desc = string.format(
		_("Checks that the code conforms to the GS1 General Specifications \z
		   (%s) for trade items scanned in general retail POS and not general \z
		   distribution (%s table 1).  The human readable representation is \z
		   provided as the output."),
		gs_version,
		gs_section
	)

	return { name = plugin_name, desc = long_desc, default_on = true }
end

local on_demand_fmt = N_("The allowance for X-dimensions between %s and %s is \z
                          only applicable to on demand print processes. For \z
                          all other printing processes, an X-dimension of %s \z
                          is the minimum allowable size.")

-- Permitted symbologies: if values are not defined, use generics
local spec = {
	ean8    = {},
	ean13   = {},
	ean13_2 = {},
	ean13_5 = {},
	upce    = {},
	upce_2  = {},
	upce_5  = {},
	upca    = {},
	upca_2  = {},
	upca_5  = {},

	databar = {
		height = {
			scalar = 46  -- Min height = 46 * X-dimension
		},
	},

	databar_expanded = {},

	generic = {
		mod_size = {
			min = 249,  -- in microns
			max = 660,  -- in microns
			note_fmt = on_demand_fmt,
			note_args = { 249, 264, 264 },
		},
		cutoff = {  -- Do not recommend for mod sizes beyond these limits
			max = 660  -- in microns
		},
		pass_grade = 1.5,  -- grade C
		aperture = 150,    -- ref 06
	},
}

local function mk_tm_ai_list(ai_tab)
	local ret = {}

	for k, v in ipairs(ai_tab) do
		ret[v] = true
	end

	return ret
end

local tm_ais = mk_tm_ai_list({
	"310", "311", "312", "313", "314", "315", "316",
	"320", "321", "322", "323", "324", "325", "326", "327", "328", "329",
	"350", "351", "352", "356", "357",
	"360", "361", "364", "365", "366"
})

local subsymb_req_tm = {
	databar_expanded = true
}

local function has_req_ais(aicheck_output)
	local has_gtin, has_tm = false, false

	for i, v in ipairs(aicheck_output.ais) do
		if v.ai == "01" then
			has_gtin = true
		elseif (v.ai == "30") or tm_ais[v.ai:sub(1, 3)] then
			has_tm = true
		end
	end

	return (has_gtin and has_tm)
end

-- Returns aperture in accordance with the GS1 Genereral Specifications
function acv_plugin_recommend(info)
	local di = info.decode_info
	local is_dpm = utils.is_dpm(info)

	if subsymb_req_tm[di.subsymb] and
	   not has_req_ais(gs1u.aicheck(di.msg, di.subsymb)) then
		return -1
	end

	return gs1u.get_rec_aperture(spec, di.subsymb, di.module_width, is_dpm)
end

local function get_missing_ai_error()
	return {
		title  = _("Missing AI"),
		status = gs1u.plugin_status.fail,
		desc   = _("Expected GTIN and variable measure AIs"),
		notes  = _("This carrier is only permitted for variable measure fresh \z
		            food trade items.  It must contain a GTIN (01), as well \z
		            as a variable count or trade measure AI: (30), (31nn), \z
		            (32nn), (35nn), (36nn).")
	}
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local pl = info.code.param_list
	local xdim = gs1u.get_min_mod_size(pl)
	local is_dpm = utils.is_dpm(info.code)
	gs1u.set_metric(info.metric)

	local results = { desc = plugin_name }

	if gs1u.results_applicable(spec, di.subsymb, vi.aperture,
	                           xdim, info.always_show, is_dpm) then
		if #di.msg == 0 then
			return utils.get_results_no_msg(results)
		end

		if subsymb_req_tm[di.subsymb] then
			local aicheck_output = gs1u.aicheck(di.msg, di.subsymb)
			local missing_err = nil

			if not has_req_ais(aicheck_output) then
				-- Symbology & size are applicable, but data content is not.
				if not info.always_show then
					return { status = gs1u.plugin_status.na }
				end

				missing_err = get_missing_ai_error()
			end

			results.details = gs1u.get_plugin_details(aicheck_output)
			table.insert(results.details, missing_err)
			results.output = aicheck_output.human_readable
		else
			results.details = {}
			results.output = utils.parse_msg(di.msg, {})
		end

		gs1u.do_application_checks(results.details, spec, pl,
		                           di.subsymb, vi.overall_grade, vi.aperture)

		results.pass_grade = gs1u.get_pass_grade(spec, di.subsymb, xdim)
		results.status = gs1u.get_status(results.details)
	else
		utils.set_results_na(results, info.always_show, is_dpm)
	end

	return results
end
