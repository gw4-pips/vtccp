--require "strict"
--dbg = require "dbg"

aicu = require "aicheckutils"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("CIP")

function acv_plugin_info(info)
	return {
		name = plugin_name,
		desc = _("DEPRECATED") .. "\n\n" ..
		       _("Complete Application Identifier evaluation and validation \z
		          according to the GS1 General Specifications.  Additional \z
		          checks validating the CIP requirements."),
	}
end

local function mk_ai(tai, tdesc)
	return { ai = tai, desc = tdesc, }
end

local ai_info = {
	mk_ai("01", N_("Product Code")),
	mk_ai("17", N_("Expiration Date")),
	mk_ai("10", N_("Batch Number")),
-- No longer check for unwanted AIs or AI order
--	mk_ai("21", _("Serial Number"),   false),
--	mk_ai("11", _("FAB Number"),      false),
--	mk_ai("91", _("Data"),            false),
}

local spec = {
	ecc_200_fnc1_1_5 = {  -- GS1 DataMatrix
		mod_size = {
			min = 255,  -- in microns
			max = 615,  -- in microns
		},
		aperture = 200,
	},

	generic = {
		pass_grade = 1.5,  -- grade C
	},
}

-- Returns aperture in accordance with the GS1 Genereral Specifications
function acv_plugin_recommend(info)
	local di = info.decode_info
	local is_dpm = utils.is_dpm(info)
	return aicu.get_rec_aperture(spec, di.subsymb, di.module_width, is_dpm)
end

local function check_ntin_prefix(plugin_details, aicheck_output)
	for k, v in ipairs(aicheck_output.ais) do
		if v.ai == "01" then
			if v.data:sub(1, 5) ~= "03400" then
				plugin_details[k].errors = plugin_details[k].errors or {}
				table.insert(plugin_details[k].errors, _("Invalid prefix"))
				plugin_details[k].status = aicu.plugin_status.fail
			end
		end
	end
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local pl = info.code.param_list
	local xdim = aicu.get_min_mod_size(pl)
	local is_dpm = utils.is_dpm(info.code)
	aicu.set_metric(info.metric)

	local results = { desc = plugin_name }

	if aicu.results_applicable(spec, di.subsymb, vi.aperture,
	                           xdim, info.always_show, is_dpm) then
		if #di.msg == 0 then
			return utils.get_results_no_msg(results)
		end

		local aicheck_output = aicu.aicheck(di.msg, di.subsymb,
		                                    { healthcare = true })
		results.details = aicu.get_plugin_details(aicheck_output)
		results.output = aicheck_output.human_readable

		check_ntin_prefix(results.details, aicheck_output)

		aicu.check_missing(results.details, aicheck_output, ai_info)
		-- Check grade, aperture, mod sizes
		aicu.do_application_checks(results.details, spec, pl,
		                           di.subsymb, vi.overall_grade, vi.aperture)

		table.insert(results.details, 1, {
			title = plugin_name,
			value = _("DEPRECATED"),
			status = utils.plugin_status.warn,
			desc = _("CIP is no longer in use, please enable the Pharma Pack plugin instead"),
		})

		results.pass_grade = aicu.get_pass_grade(spec, di.subsymb, xdim)
		results.status = aicu.get_status(results.details)
	else
		utils.set_results_na(results, info.always_show, is_dpm)
	end

	return results
end
