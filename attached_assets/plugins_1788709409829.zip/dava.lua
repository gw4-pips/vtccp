gs1u = require "aicheckutils"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("DAVA Healthcare")

function acv_plugin_info(info)
	return {
		name = plugin_name,
		desc = _("Complete Application Identifier evaluation and validation \z
		          according to the GS1 General Specifications.  Additional \z
		          checks validating the requirements of public notice no. 52/\z
		          2015-2020 from the Director General of Foreign Trade (DGFT)."),
	}
end

local on_demand_fmt = N_("The allowance for X-dimensions between %s and %s is \z
                          only applicable to on demand print processes. For \z
                          all other printing processes, an X-dimension of %s \z
                          is the minimum allowable size.")

-- Permitted symbologies: if values are not defined, use generics
local spec = {
	gs1_128 = {
		mod_size = {
			min = 249,  -- in microns
			max = 660,  -- in microns
			note_fmt = on_demand_fmt,
			note_args = { 249, 264, 264 },
		},
		height = {
			absolute = 12.70
		},
		aperture = 150,
	},

	ecc_200_fnc1_1_5 = {  -- GS1 DataMatrix
		mod_size = {
			min = 375,
			max = 990,
			note_fmt = on_demand_fmt,
			note_args = { 375, 396, 396 },
		},
		aperture = 200,
	},

	generic = {
		pass_grade = 1.5,  -- grade C
	},
}

local function mk_ai(tai, tdesc)
	return { ai = tai, desc = tdesc, }
end

local ai_info = {
	mk_ai("01", N_("GTIN")),
	mk_ai("21", N_("Serial Number")),
	mk_ai("17", N_("Expiration Date")),
	mk_ai("10", N_("Batch Number")),
}

-- Returns aperture in accordance with the GS1 Genereral Specifications
function acv_plugin_recommend(info)
	local di = info.decode_info
	local is_dpm = utils.is_dpm(info)
	return gs1u.get_rec_aperture(spec, di.subsymb, di.module_width, is_dpm)
end

local function check_indicator_digit(plugin_details, aicheck_output, subsymb)
	for k, v in ipairs(aicheck_output.ais) do
		if v.ai == "01" then
			local char = v.data:sub(1, 1)
			local digit = tonumber(char)
			local new = {
				title  = _("Indicator Digit"),
				value  = char,
				status = gs1u.plugin_status.pass,
			}

			if (not digit) or (not char:find("[01235]")) then
				new.desc = _("Invalid packaging level")
				new.status = gs1u.plugin_status.fail

			elseif digit == 0 then
				new.desc = _("Primary packaging level")
				if subsymb ~= "ecc_200_fnc1_1_5" then
					new.errors = { _("Must be encoded as GS1 DataMatrix") }
					new.status = gs1u.plugin_status.fail
				end

			elseif digit <= 3 then
				new.desc = _("Secondary packaging level")

			else  --if digit == 5 then
				new.desc = _("Tertiary packaging level")
				if subsymb ~= "gs1_128" then
					new.errors = { _("Must be encoded as GS1-128") }
					new.status = gs1u.plugin_status.fail
				end
			end

			-- Insert at top of results, then exit loop
			table.insert(plugin_details, 1, new)
			return
		end
	end
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local pl = info.code.param_list
	local xdim = gs1u.get_min_mod_size(pl)
	local is_dpm = utils.is_dpm(info.code)
	gs1u.set_metric(info.metric)

	local results = { desc = plugin_name }

	if gs1u.results_applicable(spec, di.subsymb, vi.aperture,
	                           xdim, info.always_show, is_dpm) then
		if #di.msg == 0 then
			return utils.get_results_no_msg(results)
		end

		local aicheck_output = gs1u.aicheck(di.msg, di.subsymb,
		                                    { healthcare = true })
		results.details = gs1u.get_plugin_details(aicheck_output)
		results.output = aicheck_output.human_readable

		gs1u.check_missing(results.details, aicheck_output, ai_info)
		--[[ The DGFT spec doesn't mention if the order matters, only that it
		     follows from the genspec, so for now don't check the order. ]]
		-- gs1u.check_unwanted(results.details, aicheck_output, ai_info)
		-- gs1u.check_order(results.details, aicheck_output, ai_info)
		check_indicator_digit(results.details, aicheck_output, di.subsymb)

		gs1u.do_application_checks(results.details, spec, pl,
		                           di.subsymb, vi.overall_grade, vi.aperture)

		results.pass_grade = gs1u.get_pass_grade(spec, di.subsymb, xdim)
		results.status = gs1u.get_status(results.details)
	else
		utils.set_results_na(results, info.always_show, is_dpm)
	end

	return results
end
