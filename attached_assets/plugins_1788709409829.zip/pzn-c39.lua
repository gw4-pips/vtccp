require "gettext-utils"
utils = require "utils"

local plugin_name = _("PZN - Code 39")

function acv_plugin_info(info)
	return {
		name = plugin_name,
		desc = _("Validates data content and print quality requirements of \z
		          Code 39 Pharmazentralnummer symbols according to the IFA \z
		          coding system v2.2 (2020)."),
		default_on = true,
	}
end

local spec = {
	mod_size = {
		min = 187,
		max = 450,
	},

	pass_grade = 1.5,  -- Grade C, fail if lower
	aperture = 150,    -- 06 ref num
}

local check_symb = {
	code39 = true,
}

function acv_plugin_recommend(info)
	local di = info.decode_info

	if check_symb[di.subsymb] and (di.msg:sub(1, 1) == '-') then
		return spec.aperture
	end

	return -1
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	utils.set_metric(info.metric)

	local results = { desc = plugin_name }

	if not check_symb[di.subsymb] then
		if not info.always_show then
			return { status = utils.plugin_status.na }
		end

		results.output = _("Error! Unexpected symbology, this plugin can only check:") ..
		                 utils.get_fullsymb_list(check_symb, "linear")
		results.status = utils.plugin_status.fail

		return results
	end

	local vi = info.code.verification_info
	local pl = info.code.param_list
	local prefix = di.msg:match("^[%D]?")

	if (prefix ~= '-') and not info.always_show then
		return { status = utils.plugin_status.na }
	end

	results.pass_grade = spec.pass_grade
	results.details = {}

	local new = {
		title  = _("Prefix"),
		value  = utils.parse_msg(prefix),
		desc   = _("PZN system identifier ('-')"),
		status = (prefix == '-') and utils.plugin_status.pass
		                          or utils.plugin_status.fail
	}
	table.insert(results.details, new)

	local pzn = di.msg:sub(#prefix + 1)
	new = {
		title  = _("PZN"),
		value  = utils.parse_msg(pzn),
		desc   = _("Pharmazentralnummer - 8 digits"),
		status = utils.plugin_status.pass,
		errors = {}
	}

	if #pzn ~= 8 then
		new.status = utils.plugin_status.fail
		table.insert(new.errors, (#pzn > 8) and _("Field too long") or
		                                        _("Field too short"))
	end

	if not pzn:find("^%d+$") then
		new.status = utils.plugin_status.fail
		table.insert(new.errors,
		             string.format("%s: %s", _("Invalid characters"),
		                           utils.parse_msg((pzn:gsub("%d", '')))))
	end

	table.insert(results.details, new)

	local cdx, cdr = utils.mod11_pzn_check(pzn)

	if cdx then
		new = {
			title  = _("Check digit"),
			value  = utils.parse_msg(cdr),
			desc   = _("Modulo 11 check digit"),
			status = utils.plugin_status.pass,
		}

		if cdx ~= cdr then
			-- Wrong check digit means whole PZN is wrong
			results.details[#results.details].status = utils.plugin_status.fail

			new.desc = string.format(_("Modulo 11 check digit - expected: '%s'"), cdx)
			new.status = utils.plugin_status.fail
		end

		table.insert(results.details, new)
	end

	if utils.get_status(results.details) == utils.plugin_status.fail then
		results.output = utils.parse_msg(di.msg)
	else
		results.output = "PZN - " .. utils.parse_msg(pzn)
	end

	utils.check_grade(results.details, vi.overall_grade, spec.pass_grade)
	utils.check_aperture(results.details, vi.aperture, spec.aperture)
	utils.check_mod_size(results.details, pl, spec.mod_size)

	-- Nominal 10mm @ 250µm implies minimum (target) of 7.5mm @ 187µm ?
	-- Or permitted range of 8-20mm @ 250µm, implies ~6mm @ 187µm ???
	-- If 8mm @ 250µm really is the limit, and the height needs to scale with
	-- the xdim, then just use min_height = 32X.  That doesn't take into account
	-- the the W:N ratio though, so wouldn't it make more sense to just check
	-- for >= 15% aspect ratio as suggested in ISO 16388?

	-- Code 39 already requires W:N between 2 & 3, do we need to repeat it?

	results.status = utils.get_status(results.details)

	return results
end
