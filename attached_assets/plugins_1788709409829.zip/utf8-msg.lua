--require "strict"
--dbg = require "dbg"
local utils = require "utils"
require "gettext-utils"
--local utf8_validator = require 'utf8_validator'

local plugin_name = _("UTF-8 Message")

function acv_plugin_info(info)
	return {
		name = plugin_name,
		desc = _("Display the code message in UTF-8, if valid."),
		default_on = true,
	}
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local msg_is_utf8, dummy = utf8.len(di.msg)
	local results = { desc = plugin_name }

	if info.always_show then
		if (#di.msg < 1) or (not msg_is_utf8) then
			results.status = utils.plugin_status.fail
			results.output = _("Invalid UTF-8")
			return results
		end
	else
		if (#di.msg < 1) or utils.is_ascii(di.msg) or (not msg_is_utf8) then
			return { status = utils.plugin_status.na }
		end
	end

	-- We've got valid UTF-8.  Lazarus uses UTF-8, so we just need to escape
	-- control and function characters.
	results.status = utils.plugin_status.pass
	results.output = utils.parse_msg(di.msg, { fnc = true, ctrl = true,
	                                           whitespace = false, hibit = false })
	return results
end

