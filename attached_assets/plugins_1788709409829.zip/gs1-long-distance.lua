gs1u = require "aicheckutils"
utils = require "utils"
require "gettext-utils"

local plugin_name = _("GS1 long distance")

function acv_plugin_info(info)
	local gs_version = "v26.0"
	local gs_section = "5.12.3"
	local long_desc = string.format(
		_("Checks that the code conforms to the GS1 General Specifications \z
		   (%s) for durable labelling and durable marking enabling long \z
		   distance scanning (%s table 13).  The human readable \z
		   representation is provided as the output."),
		gs_version,
		gs_section
	)

	local long_name = _("GS1 long distance scanning")
	return { name = long_name, desc = long_desc }
end

-- Permitted symbologies: if values are not defined, use generics
local spec = {
	gs1_128 = {
		mod_size = {
			min = 495,
			max = 940,
		},
		height = {
			absolute = 12.70
		},
	},

	ecc_200_fnc1_1_5 = {},  -- GS1 DataMatrix
	["2005_fnc1_1"]  = {},  -- GS1 QR

	generic = {
		mod_size = {
			min =  495,
			max = 3500,
		},
		pass_grade = 1.5,  -- grade C
		aperture = 0.8,    -- 80% of the module size
	},
}

-- Returns aperture in accordance with the GS1 Genereral Specifications
function acv_plugin_recommend(info)
	local di = info.decode_info
	local is_dpm = utils.is_dpm(info)
	return gs1u.get_rec_aperture(spec, di.subsymb, di.module_width, is_dpm)
end

function acv_plugin_result(info)
	local di = info.code.decode_info
	local vi = info.code.verification_info
	local pl = info.code.param_list
	local xdim = gs1u.get_min_mod_size(pl)
	local is_dpm = utils.is_dpm(info.code)
	gs1u.set_metric(info.metric)

	local results = { desc = plugin_name }

	if gs1u.results_applicable(spec, di.subsymb, vi.aperture,
	                           xdim, info.always_show, is_dpm) then
		if #di.msg == 0 then
			return utils.get_results_no_msg(results)
		end

		results.details, results.output = gs1u.get_aicheck_results(di.msg, di.subsymb)

		gs1u.do_application_checks(results.details, spec, pl,
		                           di.subsymb, vi.overall_grade, vi.aperture)

		results.pass_grade = gs1u.get_pass_grade(spec, di.subsymb, xdim)
		results.status = gs1u.get_status(results.details)
	else
		utils.set_results_na(results, info.always_show, is_dpm)
	end

	return results
end
