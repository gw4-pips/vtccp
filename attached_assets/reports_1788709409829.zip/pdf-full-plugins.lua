local u = require "utils"
require "gettext-utils"

function acv_report(info)
	local tl = require "template-loader"
	local pdf_outfile = info.outfile

	-- This needs to improve.  Maybe find the directory of the script and use
	-- that as a base?
	info.template = "scripts/reports/full-plugins.html"
	info.outfile = u.get_tmpname(info.tempdir, nil, ".html")
	--print("temp file: " .. info.outfile)
	tl.create_report(info)

	-- Webkit still doesn't properly support CSS page at-rules, hence the manual
	-- setting of page numbers: https://bugs.webkit.org/show_bug.cgi?id=15548
	-- If they ever fix it, we can just use CSS instead:
	--	@page { @bottom { content: counter(page) " / " counter(pages); } }
	-- Also, margin-bottom set to 10mm so that page number doesn't look stupid.
	acv_exec("wkhtmltopdf", "--print-media-type", "--disable-smart-shrinking",
	         "--margin-left", "15mm", "--margin-right",  "15mm",
	         "--margin-top",  "15mm", "--margin-bottom", "10mm",
	         "--footer-center", "[page] / [topage]", "--dpi", "300",
	         info.outfile, pdf_outfile)
	os.remove(info.outfile)
end

function acv_report_info(info)
	return { name = _("Detailed plugins (PDF)"), extension = ".pdf" }
end
