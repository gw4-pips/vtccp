ReadMe.TXT for extras folder


This folder, "Extras", contains three sub-folders. They are:


Plugins
-------
Contains a selection of data content analysis plugins for the Verifier which are not part of the standard intallation in Setup.EXE, but which may be of interest or use. You can install these as required by inserting the CD and clicking the "Install Optional Plugins" button, or by copying them into the same folder as Verifier.EXE (usually <Program Files>\Axicon\Verifier).

Plugins\Obsolete
----------------
Plugins which have been superseded, or which pertain to obsolete application standards.


System
------
Contains updates to Windows system files which may be required by the verifier.

Utils
-----
Contains various utility programs to work in conjunction with the verifier. These include:

DecodeConfig.exe:
Decode configuration utility for the PC Verifier. You don't need to use this

PluginStub.exe:
A program to allow testing and use of Axicon Verifer Plugins separately from the main Verifier program.

SetupScanDB.exe:
This installs the Scan File Data Extractor onto your computer.

ScanFix.exe:
'Saved Scan Repair Tool' - attempts to repair saved scan files that the verifier cannot open

Console.exe:
A text-based user interface for the PC Verifier software.

ResetRemoteWakeup.exe:
A program to alter the settings of USB verifiers to allow laptop computers to be put to sleep whilst the reader is attached.

