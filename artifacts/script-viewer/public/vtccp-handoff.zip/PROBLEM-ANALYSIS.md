# VTCCP — DMST TC Panel Image Blank: Complete Problem Analysis

**Date compiled**: 2026-06-01  
**Status**: Unresolved after 5 fix attempts. Handing off for fresh analysis.  
**Prepared for**: Another Claude instance with no prior context.

---

## 1. System Overview

### Device
- **Model**: Cognex DataMan DM475V-63530E-PIPS-Verif-Lab  
- **IP**: 10.10.10.7  
- **Firmware**: 6.1.16_sr4  
- **Port 23**: Raw DMCC text (Telnet-style). `||>COMMAND\r\n` format. Confirmed working.  
- **Port 44444**: Multiplexed — Cognex SDK binary protocol AND HTTP pub/sub. Both on same port.

### What VTCCP is
A Windows WPF / C# / .NET 8 application that connects to the DM475V barcode verifier and:
1. Sends a software trigger to fire a TruCheck verification scan
2. Receives the verification result (XML + image) via HTTP pub/sub
3. Writes results to Excel

### What DMST is
The Cognex DataMan Setup Tool — the vendor's native Windows application. It has a "TC" (TruCheck) panel that shows the post-scan verification image and grade summary. This is the reference display for verifying the image is being delivered correctly.

### Two-application coexistence problem
VTCCP and DMST both want to be connected to the same device simultaneously.
- DMST: uses HTTP pub/sub on port 44444 for results and HTML reports
- VTCCP: uses Cognex SDK (also port 44444) + raw TCP trigger on port 23 + HTTP pub/sub on port 44444

---

## 2. The Symptom

**Without VTCCP running**: DMST TC panel shows the barcode image after every scan — correct behaviour.

**With VTCCP connected**: DMST TC panel shows no image after scans. The grade letters/numbers are present; only the image is absent.

**The image IS captured and IS present in the push XML** (`JpegImageBase64` populated, codes.xml ~186 KB). VTCCP receives the image. DMST does not display it.

**The image IS present in the DMST HTML report** (pcm_report.html, which the HTML scraper also confirms). The failure is specifically in the TC panel live display — not in HTML archival.

**Testing procedure used**: 
- Scan 1: DMST closed, VTCCP triggers scan via raw TCP (TRIGGER ON on port 23). After scan, open DMST and check TC panel → no image.
- Scan 2: DMST open, DMST triggers TC scan from its own GUI. Check TC panel → no image.
- Both conditions fail identically.

---

## 3. Confirmed Root Cause Measurement

**Before any fix attempts**, a raw port-23 Telnet probe confirmed:

```
GET LIVEIMG.MODE   →  0      (while VTCCP connected via SDK)
GET DATA.IMAGE-TYPE →  0
```

**Reference value**: `GET LIVEIMG.MODE` = `2` is believed to be the correct value for "send image with each result."  
**CRITICAL CAVEAT**: We **never measured LIVEIMG.MODE without VTCCP connected**. The value `2` is assumed, not confirmed. The correct value could be `1` or another value entirely.

**SDK's role**: The Cognex SDK's `DataManSystem.Connect()` internally sends DMCC commands that alter device parameters. Specifically, it sets `DATA.IMAGE-TYPE`, `DATA.RESULT-TYPE`, and related parameters, then persists them via an internal `COM.DMCC-SAVE`. This is documented in the code (see DataManSdkClient.cs class comment). Whether Connect() also sets `LIVEIMG.MODE` is unconfirmed but suspected.

---

## 4. SDK Behaviour — What We Know

### What Connect() does (confirmed by observation)
- Opens TCP connection to port 44444
- Sends internal DMCC commands (unknown full set)
- Throws and **catches** an `OperationCanceledException` internally — this appears as `Exception thrown: 'System.OperationCanceledException' in System.Private.CoreLib.dll` in VS Output at the same position in EVERY test run, including tests where our code has zero OCE-generating calls. **This is the SDK's own internal exception, not our code.** It has been a red herring throughout.

### SDK command whitelist (confirmed blocked via InvalidCommandException)
The SDK validates command names before sending to the device. Commands NOT on its internal list throw `InvalidCommandException` and **never reach the wire**:
- `COM.DMCC-RESET` — blocked
- `COM.DMCC-SAVE` — blocked
- `GET FIRMWARE.VER` — blocked (use `_system.FirmwareVersion` property instead)
- `TRIGGER` / `TRIGGER 1` — blocked (bypass via raw TCP on port 23)
- `GET SYMBOL.RESULT` — blocked

### Commands with unknown whitelist status
- `SET LIVEIMG.MODE 2` — attempted in fix5; unknown if allowed
- `CONFIG.SAVE` — attempted in fix5; unknown if allowed

### `SetResultTypes()` — intentionally NOT called
The SDK has a `SetResultTypes()` method. Calling it sends `DATA.IMAGE-TYPE`, `DATA.RESULT-TYPE`, `DATA.RESULT-ENCODING`, `DATA.RESULT-ALWAYSSEND` and persists them via `COM.DMCC-SAVE`. This is known to strip image data from DMST. VTCCP deliberately does NOT call it.

---

## 5. VS Debug Output — What It Can and Cannot Show

### The DLL-loading blind window
`[VTCCP-SDK]` debug lines written from inside `Task.Run(() => _system.Connect(...))` are **never visible** in VS Output. They are emitted during the heavy DLL-loading startup phase (roughly lines 1–79 of the VS Output), during which VS discards debug output from background threads.

Evidence: In fix5, `Debug.WriteLine("[VTCCP-SDK] Connected...")` and `Debug.WriteLine("[VTCCP-SDK] Attempting LIVEIMG.MODE restore...")` are present in code but absent from output. They run successfully (the HTTP subscriber starts immediately after, confirming `Task.Run` completed).

**Implication**: We cannot determine from VS Output whether `SET LIVEIMG.MODE 2` via SDK succeeded or threw `InvalidCommandException` in fix5.

### Lines that DO appear reliably
- `[VTCCP-HTTP-SUB]` lines — emitted after startup, always visible
- `[VTCCP-DMCC]` lines — trigger path, always visible
- `[VTCCP-SCRAPER]` lines — scraper events, always visible
- `[VTCCP-BUILD]` — the startup banner, always visible

---

## 6. Fix Attempts — Chronological

### Fix 2: Port-23 restore with CancellationToken banner drain
**Approach**: Open new `TcpClient` to port 23, drain welcome banner with `CancellationTokenSource(300ms)` + `stream.ReadAsync`, then send:
```
SET COM.DMCC-RESPONSE 2
COM.DMCC-RESET
COM.DMCC-SAVE
SET LIVEIMG.MODE 2
CONFIG.SAVE
```
**Result**: **Failed**. The `CancellationToken`-based `ReadAsync` cancelled after 300ms and faulted the `NetworkStream`'s IO completion port. All subsequent `WriteAsync` calls on the same stream threw silently. Commands never reached the device.  
**Evidence**: No `[VTCCP-SDK]` lines visible; image still blank.

---

### Fix 3: Port-23 restore with `ReadTimeout` banner drain
**Approach**: Same as fix2, but replaced CancellationToken banner drain with `stream.ReadTimeout = 200; stream.Read(...); catch {}`. This avoids faulting the socket. Ack drain at END of method uses `CancellationTokenSource(600ms)`.  
**Result**: **Failed**. Image still blank.  
**Analysis**: The commands very likely DID reach the device. The `OperationCanceledException` at VS Output line 80 is from the 600ms ack-drain timeout at the END of the method — after all writes completed. But either `LIVEIMG.MODE=2` is the wrong value, or the SDK has a background thread overwriting it, or `LIVEIMG.MODE` is not the root cause.

---

### Fix 4: Port-23 restore with full diagnostic GET read-back
**Approach**: Added `GET LIVEIMG.MODE` before the SET and after the SET and after `CONFIG.SAVE`, with full ACK read-back in extended response mode. Also re-enables `COM.DMCC-RESPONSE 2` after `COM.DMCC-RESET` (which resets it to 0).  
**Result**: **Failed**. Image still blank.  
**Problem**: All `[VTCCP-SDK]` diagnostics from within the restore method are invisible in VS Output (emitted during DLL-loading window). We cannot read the `GET LIVEIMG.MODE` responses to know what the device actually reported.

---

### Fix 5: SDK-side restore via `_system.SendCommand()`
**Approach**: Removed all port-23 code from ConnectAsync. After `_system.Connect()` completes inside `Task.Run`, immediately call:
```csharp
_system.SendCommand("SET LIVEIMG.MODE 2");
_system.SendCommand("CONFIG.SAVE");
```
This uses the SDK's already-open port 44444 connection, bypassing port 23 entirely.  
**Result**: **Failed**. Image still blank. DMST closed for scan 1, DMST open for scan 2 — both show no image.  
**VS Output from fix5**: No `[VTCCP-SDK]` lines visible (DLL-loading blind window). Cannot determine if SDK whitelist blocked these commands or if they executed and had no effect.

---

## 7. Fix 5 Debug Output (Full)

This is the most complete and clean test. Two scans triggered during the same session:
- Scan 1 (line 95–115): VTCCP-triggered via port 23, DMST closed
- Scan 2 (line 164–175): DMST-triggered TC scan, DMST open

Key observations:
- Line 80: OCE = **SDK internal exception from Connect()**, not our code. Present in every test.
- Lines 95–101: Trigger via port 23 works perfectly.
- Lines 102–105: Scan 1 — codes.xml 186,194 bytes (full verify data with image), pcm_report.html received.
- Lines 164–167: Scan 2 — codes.xml 186,314 bytes (full verify data with image), pcm_report.html received.
- Lines 131–159: Between scans — monitor-mode codes.xml (~10 KB, no image) at ~1/second.
- No `[VTCCP-SDK]` lines anywhere.

```
[line 79]  System.Net.Sockets.dll Loaded
[line 80]  Exception thrown: 'System.OperationCanceledException' in System.Private.CoreLib.dll
[line 81]  [VTCCP-HTTP-SUB] Subscribed to 10.10.10.7:44444/events. Receive loop starting.
...
[line 95]  [VTCCP-DMCC] Trigger attempt: 10.10.10.7:23 (raw DMCC port)  connect=3000ms  response=5000ms  idle=150ms
[line 96]  Exception thrown: 'System.OperationCanceledException' in System.Private.CoreLib.dll
[line 97]  [VTCCP-DMCC] Banner wait timed out (no banner).
[line 98]  [VTCCP-DMCC] SET COM.DMCC-RESPONSE 2 sent.
[line 99]  [VTCCP-DMCC] TRIGGER ON sent.
[line 100] [VTCCP-DMCC] TRIGGER raw response (22B): '||:::2[0]\r\n||:::2[0]\r\n'
[line 101] [VTCCP-DMCC] TRIGGER response: code=0  body='||:::2[0]'
[line 102] [VTCCP-HTTP-SUB] PUT /pcm_report.html HTTP/1.1 (120191 B)
[line 103] [VTCCP-SCRAPER] ParseHtml: ECLevel=null DataMask=null ECI=null Polarity=White on black DataCW=30 ECBudget=20 EncodedChars=49
[line 104] [VTCCP-HTTP-SUB] pcm_report.html parsed: ok=True polarity=White on black ECLevel=null DataCW=30
[line 105] [VTCCP-HTTP-SUB] PUT /codes.xml HTTP/1.1 (186194 B)
[line 108] [VTCCP-HTTP-SUB] Push XML decoded: 21508 chars.
[line 109] [VTCCP-VALID] 6 discrepancy(s) — 20:27:16:
             EncodedCharacters:Push=31,Html=49
             GNU%:Push=37.7,Html=0.4
             SC%:Push=67.7,Html=68
             ErrorsCorrected:Push=1,Html=null
             ErrCapUsed:Push=2,Html=null
             ImagePolarity:Push=null,Html=White on black
[lines 131-159] monitor-mode codes.xml (~10 KB each) — DMST opened, idle monitoring
[line 164] [VTCCP-HTTP-SUB] PUT /pcm_report.html HTTP/1.1 (120219 B)
[line 165] [VTCCP-SCRAPER] ParseHtml: ECLevel=null DataMask=null ECI=null Polarity=White on black DataCW=30 ECBudget=20 EncodedChars=49
[line 166] [VTCCP-HTTP-SUB] pcm_report.html parsed: ok=True polarity=White on black ECLevel=null DataCW=30
[line 167] [VTCCP-HTTP-SUB] PUT /codes.xml HTTP/1.1 (186314 B)
[line 168] [VTCCP-HTTP-SUB] Push XML decoded: 21537 chars.
[line 169] [VTCCP-VALID] 6 discrepancy(s) — 20:27:36:
             EncodedCharacters:Push=31,Html=49
             GNU%:Push=37.7,Html=0.4
             SC%:Push=67.3,Html=67
             ErrorsCorrected:Push=1,Html=null
             ErrCapUsed:Push=2,Html=null
             ImagePolarity:Push=null,Html=White on black
[line 178] Exception thrown: 'System.OperationCanceledException' in System.Private.CoreLib.dll
[line 179] [VTCCP-HTTP-SUB] Receive loop ended.
[line 180] [VTCCP-HTTP-SUB] Stopped.
```

Note on line 96 OCE: this is from the VTCCP trigger path's own banner-drain, using `CancellationTokenSource` — confirmed harmless, the trigger still succeeds (line 100 shows ACK received).

---

## 8. Remaining Hypotheses — Not Yet Tested

### 8.1 Wrong LIVEIMG.MODE value
We assumed the correct value is `2`. We measured `0` with VTCCP connected. We **never measured the baseline** (without VTCCP). If the correct value is `1` (not `2`), all five fixes sent the wrong value.

**Test**: With VTCCP NOT running, Telnet to port 23, run `GET LIVEIMG.MODE`. Record actual value. Also run `GET DATA.IMAGE-TYPE`, `GET DATA.RESULT-TYPE`, `GET DATA.RESULT-ENCODING`.

### 8.2 SDK background thread continuously re-writing LIVEIMG.MODE=0
The Cognex SDK may have a heartbeat or parameter-sync thread that periodically re-sends device configuration (including LIVEIMG.MODE=0) as part of maintaining the connection. If so, any change we make is immediately overwritten.

**Test**: With VTCCP connected, from a SEPARATE raw Telnet session on port 23, poll `GET LIVEIMG.MODE` every 2 seconds for 30 seconds. If it keeps returning 0 regardless of what we write, the SDK is actively re-writing it.

**Test 2**: Decompile `Cognex.DataMan.SDK.PC.dll` with ILSpy or dotPeek. Search for timer threads, background tasks, and any code that calls SET commands or COM.DMCC-SAVE.

### 8.3 LIVEIMG.MODE is not the root cause — DATA.IMAGE-TYPE is
We confirmed `DATA.IMAGE-TYPE = 0` with VTCCP connected and called it "correct." But:
- `DATA.IMAGE-TYPE = 0` in DMCC means **no image** in DMCC result delivery
- `DATA.IMAGE-TYPE = 1` = JPEG, `2` = uncompressed

DMST's TC panel image may come from the **DMCC result channel** (not HTTP pub/sub). If so, `DATA.IMAGE-TYPE=0` (set by SDK) would blank the TC panel even if the HTTP pub/sub codes.xml has image data.

`COM.DMCC-RESET` is documented to reset `DATA.IMAGE-TYPE` back to firmware default. Our fix attempts include `COM.DMCC-RESET`, but we cannot confirm the commands actually executed (see §5 on the DLL-loading blind window).

**Test**: With VTCCP connected, Telnet port 23, run `GET DATA.IMAGE-TYPE`. If it returns `0`, try `SET DATA.IMAGE-TYPE 1` and check if the TC panel image appears without any LIVEIMG.MODE change.

### 8.4 Fix5 SET LIVEIMG.MODE 2 was blocked by SDK whitelist
In fix5, `_system.SendCommand("SET LIVEIMG.MODE 2")` may have thrown `InvalidCommandException`. The `[VTCCP-SDK]` debug lines that would confirm this are invisible during the DLL-loading window.

**Test**: Add a `File.WriteAllText(@"C:\temp\vtccp-sdk-log.txt", logMessage)` call inside `TrySendViaSdk` to write the result to disk instead of Debug.WriteLine. This bypasses the VS output suppression entirely.

### 8.5 SDK Connect() changes more than LIVEIMG.MODE
The full set of DMCC commands sent internally by `EthSystemConnector.Connect()` is unknown. It may set parameters beyond what we've been trying to restore.

**Test**: Decompile the SDK DLL. Look at `EthSystemConnector.Connect()` and every method it calls. List every DMCC SET command and COM.DMCC-SAVE it sends.

### 8.6 The TC panel image uses a dedicated SDK image channel
The TC panel image may not come from codes.xml at all. DMST may use the SDK's `DataManSystem.XmlResultArrived` event or a separate image subscription that the SDK provides — and the SDK may suppress image delivery to DMST when it detects another SDK client is connected.

**Test**: Check Wireshark capture of DMST's network traffic during a scan (without VTCCP), filtered to port 44444. Does DMST receive codes.xml? Or does it use a different protocol message for the TC image?

---

## 9. Key Facts Established (Do Not Re-Investigate These)

| Fact | Evidence |
|---|---|
| LIVEIMG.MODE = 0 while VTCCP connected | Raw Telnet GET confirmed before fix attempts |
| OCE at VS Output line 80 = SDK internal | Present in fix5 with zero OCE code of our own |
| [VTCCP-SDK] lines invisible = DLL-loading window | Always absent despite being in code |
| Port 23 trigger works fine | Every test: TRIGGER ON → `||:::2[0]\r\n` ACK received |
| codes.xml 186 KB = full verify data with image | JpegImageBase64 confirmed populated in earlier probe |
| monitor codes.xml ~10 KB = no image | Lines 131-159 of fix5 output confirm |
| SDK blocks COM.DMCC-RESET via SendCommand() | InvalidCommandException confirmed via reflection test |
| SetResultTypes() not called — correct | Would strip image from ALL results |
| DATA.IMAGE-TYPE = 0 while VTCCP connected | Raw Telnet GET confirmed (called "correct" — may be wrong) |

---

## 10. What the Code Currently Does (fix5 state)

`DataManSdkClient.ConnectAsync()`:
```csharp
await Task.Run(() =>
{
    var ip     = IPAddress.Parse(_cfg.Host);
    _connector = new CognexSdk.EthSystemConnector(ip);
    _system    = new CognexSdk.DataManSystem(_connector);
    _system.Connect(_cfg.ConnectTimeoutMs);
    _isConnected = true;
    
    // These lines are present but invisible in VS Output:
    Debug.WriteLine("[VTCCP-SDK] Connected...");
    Debug.WriteLine("[VTCCP-SDK] Attempting LIVEIMG.MODE restore...");
    
    TrySendViaSdk("SET LIVEIMG.MODE 2", "LIVEIMG.MODE=2 via SDK");
    TrySendViaSdk("CONFIG.SAVE",         "CONFIG.SAVE via SDK");
    
    // TrySendViaSdk catches InvalidCommandException separately
}, ct);
```

`SendDmccRestoreAsync()` is still present in the class (with diagnostic read-back, extended ACK mode, etc.) but is no longer called from ConnectAsync or DisconnectAsync.

---

## 11. Recommended First Actions for Fresh Analysis

**Do these before writing any code:**

1. **Baseline DMCC probe** (5 minutes): With VTCCP NOT running, open PowerShell, telnet to 10.10.10.7:23, run:
   ```
   GET LIVEIMG.MODE
   GET DATA.IMAGE-TYPE
   GET DATA.RESULT-TYPE
   GET DATA.RESULT-ENCODING
   GET DATA.RESULT-ALWAYSSEND
   ```
   Record exact response values. These are the "known good" values the SDK is corrupting.

2. **File-based SDK debug** (10 minutes): In `TrySendViaSdk`, add a `File.AppendAllText(@"C:\temp\vtccp.log", ...)` call to write the result to disk. This bypasses VS output suppression and will immediately tell you if `SET LIVEIMG.MODE 2` is blocked or succeeds.

3. **Live poll after connect** (5 minutes): After VTCCP connects, from a separate PowerShell window immediately run `GET LIVEIMG.MODE` and `GET DATA.IMAGE-TYPE` via Telnet. Compare to baseline from step 1.

4. **Decompile the SDK** (variable): Use ILSpy or dotPeek on `Cognex.DataMan.SDK.PC.dll`. Find `EthSystemConnector.Connect()`. List every DMCC SET command it sends. This will definitively identify all parameters the SDK corrupts on connect.

---

## 12. Project Context (for orientation only — not directly relevant to this bug)

VTCCP uses push-mode scanning: VTCCP triggers scans via port 23 raw DMCC, results arrive via HTTP pub/sub (`GET /events?enable` → `PUT /codes.xml`). The `HttpEventSubscriber` is the primary result path. `XmlResultArrived` (SDK event) is available but not the primary path. DMST's HTML report files are parsed by `DmstHtmlScraper` (filesystem watcher on `%Documents%\{DeviceName}\CodeQuality\*.html`) to supplement the push XML with fields not available in push output (EncodedCharacters, DataCodewords, ECLevel for QR, etc.).

The SDK connection is kept open primarily because `_system.SendAsync()` is used for DMCC GET commands (device identity, trigger type, etc.) during session setup. In theory, the SDK connection could be replaced with raw TCP on port 23 for all DMCC commands — eliminating the SDK's interference with device parameters entirely. This would be fix6 if the above diagnostic steps don't resolve the issue.

---

## 13. Source Files in This Package

| File | Purpose |
|---|---|
| `DataManSdkClient.cs` | SDK wrapper — ConnectAsync, DisconnectAsync, SendAsync, SendDmccRestoreAsync (the fix target) |
| `DeviceSession.cs` | High-level orchestration — ConnectAsync chain, scraper wiring, trigger logic |
| `DmccCommand.cs` | All DMCC command string constants with documentation |
| `WORKING-NOTES.md` | Active project notes including probe results and fix history |
| `vtccp-fix5-debug-output.txt` | VS Output from the fix5 test run (most complete test data) |
